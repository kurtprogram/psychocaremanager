import { Metadata } from 'next'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowLeft } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Autenticação - PsicoGestão',
  description: 'Faça login ou cadastre-se na plataforma',
}

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left side - Brand/Info */}
      <div className="md:w-1/2 bg-gradient-to-br from-moss-500 to-moss-700 p-8 md:p-12 text-white">
        <div className="max-w-md mx-auto h-full flex flex-col justify-center">
          <Link href="/" className="inline-flex items-center mb-8">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar para o site
          </Link>
          
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              PsicoGestão
            </h1>
            <p className="text-moss-100">
              Plataforma completa de gestão para psicólogos, clínicas e empresas.
              Tudo que você precisa em um só lugar.
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-bold">1</span>
              </div>
              <div>
                <h3 className="font-semibold">Teste Grátis</h3>
                <p className="text-sm text-moss-100">
                  7 dias com todas as funcionalidades
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-bold">2</span>
              </div>
              <div>
                <h3 className="font-semibold">Sem Cartão</h3>
                <p className="text-sm text-moss-100">
                  Comece agora sem compromisso
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-bold">3</span>
              </div>
              <div>
                <h3 className="font-semibold">Escalável</h3>
                <p className="text-sm text-moss-100">
                  Cresça do plano Individual ao Empresarial
                </p>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-white/20">
            <p className="text-sm">
              Já possui uma conta?{' '}
              <Link href="/login" className="font-semibold hover:underline">
                Faça login
              </Link>
            </p>
          </div>
        </div>
      </div>

      {/* Right side - Auth Forms */}
      <div className="md:w-1/2 p-8 md:p-12 bg-background">
        <div className="max-w-md mx-auto h-full flex flex-col justify-center">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <Link href="/" className="text-2xl font-bold text-moss-600">
                PsicoGestão
              </Link>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/planos">Planos</Link>
                </Button>
              </div>
            </div>
            {children}
          </div>

          <div className="mt-8 pt-8 border-t">
            <p className="text-sm text-muted-foreground text-center">
              Ao continuar, você concorda com nossos{' '}
              <Link href="/termos" className="text-moss-600 hover:underline">
                Termos de Uso
              </Link>{' '}
              e{' '}
              <Link href="/privacidade" className="text-moss-600 hover:underline">
                Política de Privacidade
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}