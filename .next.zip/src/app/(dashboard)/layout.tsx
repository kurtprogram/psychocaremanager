'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { redirect } from 'next/navigation'
import DashboardSidebar from '@/components/layout/DashboardSidebar'
import DashboardNavbar from '@/components/layout/DashboardNavbar'
import { useToast } from '@/hooks/useToast'

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { data: session, status } = useSession()
  const { toast } = useToast()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  if (status === 'loading') {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-moss-600 mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando...</p>
        </div>
      </div>
    )
  }

  if (!session) {
    redirect('/login')
  }

  // Check trial period
  const user = session.user as any
  const trialEnd = user.trialEndsAt ? new Date(user.trialEndsAt) : null
  
  if (trialEnd && trialEnd < new Date() && user.role !== 'SUPER_ADMIN') {
    toast({
      title: 'Período de teste expirado',
      description: 'Atualize seu plano para continuar usando o sistema',
      variant: 'destructive',
    })
    redirect('/billing')
  }

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar 
        isOpen={sidebarOpen} 
        onToggle={() => setSidebarOpen(!sidebarOpen)} 
        userRole={user.role}
      />
      
      <div className={`flex-1 flex flex-col transition-all duration-300 ${
        sidebarOpen ? 'md:ml-64' : 'md:ml-20'
      }`}>
        <DashboardNavbar 
          onMenuClick={() => setSidebarOpen(!sidebarOpen)}
          sidebarOpen={sidebarOpen}
          user={user}
        />
        
        <main className="flex-1 p-4 md:p-6">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}