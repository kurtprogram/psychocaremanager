import * as React from 'react'

export function Tabs<T extends string = string>({ children, value, onValueChange, ...props }: { value?: T; onValueChange?: (value: T) => void } & React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} data-value={value}>{children}</div>
}

export function TabsList({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props}>{children}</div>
}

export function TabsTrigger({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button {...props}>{children}</button>
}

export function TabsContent({ children, value, ...props }: { value?: string } & React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} data-value={value}>{children}</div>
}
