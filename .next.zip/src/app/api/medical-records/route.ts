import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import { authConfig } from '@/lib/auth'

const medicalRecordSchema = z.object({
  patientId: z.string(),
  appointmentId: z.string().optional(),
  sessionDate: z.string().datetime(),
  sessionNumber: z.number().int().positive(),
  subjective: z.string().optional(),
  objective: z.string().optional(),
  assessment: z.string().optional(),
  plan: z.string().optional(),
  isEncrypted: z.boolean().default(true),
})

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(req.url)
    const patientId = searchParams.get('patientId')
    const professionalId = searchParams.get('professionalId')

    const medicalRecords = await prisma.medicalRecord.findMany({
      where: {
        organizationId: session.user.organizationId,
        deletedAt: null,
        ...(patientId && { patientId }),
        ...(professionalId && { professionalId }),
      },
      include: {
        patient: {
          select: {
            id: true,
            fullName: true,
          },
        },
        professional: {
          select: {
            id: true,
            name: true,
          },
        },
        appointment: {
          select: {
            id: true,
            title: true,
            startTime: true,
          },
        },
      },
      orderBy: {
        sessionDate: 'desc',
      },
    })

    return NextResponse.json(medicalRecords)
  } catch (error) {
    console.error('Error fetching medical records:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar prontuários' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const body = await req.json()
    const validated = medicalRecordSchema.parse(body)

    // Verificar número da sessão
    const lastSession = await prisma.medicalRecord.findFirst({
      where: {
        patientId: validated.patientId,
        organizationId: session.user.organizationId,
      },
      orderBy: {
        sessionNumber: 'desc',
      },
    })

    if (lastSession && validated.sessionNumber <= lastSession.sessionNumber) {
      return NextResponse.json(
        { error: 'Número de sessão inválido' },
        { status: 400 }
      )
    }

    // Criar prontuário
    const medicalRecord = await prisma.medicalRecord.create({
      data: {
        organizationId: session.user.organizationId,
        patientId: validated.patientId,
        professionalId: session.user.id,
        appointmentId: validated.appointmentId,
        sessionDate: new Date(validated.sessionDate),
        sessionNumber: validated.sessionNumber,
        subjective: validated.subjective,
        objective: validated.objective,
        assessment: validated.assessment,
        plan: validated.plan,
        isEncrypted: validated.isEncrypted,
        ...(validated.isEncrypted && {
          encryptionKey: `enc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        }),
      },
      include: {
        patient: true,
        professional: true,
      },
    })

    // Log de auditoria
    await prisma.auditLog.create({
      data: {
        organizationId: session.user.organizationId,
        userId: session.user.id,
        userEmail: session.user.email!,
        userName: session.user.name!,
        action: 'CREATE',
        entityType: 'MEDICAL_RECORD',
        entityId: medicalRecord.id,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    return NextResponse.json({
      success: true,
      medicalRecord,
    })

  } catch (error: any) {
    console.error('Error creating medical record:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Erro ao criar prontuário' },
      { status: 500 }
    )
  }
}