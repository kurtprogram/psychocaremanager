'use client'

import { useState } from 'react'
import { Calendar, Clock, Video, MapPin, User, Search, Filter, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Calendar as CalendarComponent } from '@/components/ui/calendar'
import { useToast } from '@/hooks/useToast'
import { format, isToday, isTomorrow, parseISO } from 'date-fns'
import { ptBR } from 'date-fns/locale'

const appointmentsData = [
  {
    id: 1,
    patient: 'João Silva',
    professional: 'Dra. Maria Silva',
    date: '2024-01-15T09:00:00',
    duration: 50,
    type: 'IN_PERSON',
    status: 'CONFIRMED',
    location: 'Consultório Central',
    notes: 'Primeira sessão de avaliação'
  },
  {
    id: 2,
    patient: 'Maria Santos',
    professional: 'Dra. Maria Silva',
    date: '2024-01-15T10:30:00',
    duration: 50,
    type: 'ONLINE',
    status: 'CONFIRMED',
    meetingLink: 'https://meet.google.com/abc-defg-hij',
    notes: 'Sessão semanal'
  },
  {
    id: 3,
    patient: 'Pedro Oliveira',
    professional: 'Dr. Carlos Mendes',
    date: '2024-01-15T14:00:00',
    duration: 50,
    type: 'IN_PERSON',
    status: 'PENDING',
    location: 'Sala 2',
    notes: 'Avaliação de progresso'
  },
  {
    id: 4,
    patient: 'Ana Costa',
    professional: 'Dra. Maria Silva',
    date: '2024-01-16T11:00:00',
    duration: 50,
    type: 'ONLINE',
    status: 'CONFIRMED',
    meetingLink: 'https://meet.google.com/xyz-uvw-rst'
  },
]

export default function AgendaPage() {
  const { toast } = useToast()
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [view, setView] = useState('day')
  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')

  const filteredAppointments = appointmentsData.filter(apt => {
    if (filter === 'confirmed' && apt.status !== 'CONFIRMED') return false
    if (filter === 'pending' && apt.status !== 'PENDING') return false
    if (filter === 'online' && apt.type !== 'ONLINE') return false
    if (filter === 'in_person' && apt.type !== 'IN_PERSON') return false
    if (search && !apt.patient.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'CONFIRMED': return 'bg-green-100 text-green-800'
      case 'PENDING': return 'bg-amber-100 text-amber-800'
      case 'CANCELLED': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const handleNewAppointment = () => {
    toast({
      title: 'Nova consulta',
      description: 'Abrindo formulário...',
    })
    // Implementar modal de nova consulta
  }

  const handleSendReminder = (appointmentId: number) => {
    toast({
      title: 'Lembrete enviado',
      description: 'Lembrete enviado por WhatsApp',
    })
  }

  const handleStartMeeting = (meetingLink: string) => {
    window.open(meetingLink, '_blank')
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Agenda</h1>
          <p className="text-muted-foreground">
            Gerencie suas consultas e agendamentos
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={handleNewAppointment}>
            <Plus className="mr-2 h-4 w-4" />
            Nova Consulta
          </Button>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filtros
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Calendário e Filtros */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Calendário</CardTitle>
            </CardHeader>
            <CardContent>
              <CalendarComponent
                mode="single"
                selected={date}
                onDateSelect={setDate}
                className="rounded-md border"
                locale={ptBR}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Tipo de Visualização</label>
                <Select value={view} onValueChange={setView}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="day">Dia</SelectItem>
                    <SelectItem value="week">Semana</SelectItem>
                    <SelectItem value="month">Mês</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Status</label>
                <Select value={filter} onValueChange={setFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="confirmed">Confirmados</SelectItem>
                    <SelectItem value="pending">Pendentes</SelectItem>
                    <SelectItem value="cancelled">Cancelados</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Tipo</label>
                <Select value={filter} onValueChange={setFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="online">Online</SelectItem>
                    <SelectItem value="in_person">Presencial</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Profissional</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="maria">Dra. Maria Silva</SelectItem>
                    <SelectItem value="carlos">Dr. Carlos Mendes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Estatísticas Rápidas */}
          <Card>
            <CardHeader>
              <CardTitle>Hoje</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Total de consultas</span>
                  <span className="font-semibold">3</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Confirmadas</span>
                  <span className="font-semibold text-green-600">2</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Pendentes</span>
                  <span className="font-semibold text-amber-600">1</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Online</span>
                  <span className="font-semibold">1</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Lista de Consultas */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Consultas</CardTitle>
                <p className="text-sm text-muted-foreground">
                  {date ? format(date, "EEEE, d 'de' MMMM", { locale: ptBR }) : 'Selecione uma data'}
                </p>
              </div>
              <div className="relative w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar paciente..."
                  className="pl-9"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="day" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="day">Dia</TabsTrigger>
                  <TabsTrigger value="week">Semana</TabsTrigger>
                  <TabsTrigger value="month">Mês</TabsTrigger>
                </TabsList>
                
                <TabsContent value="day" className="space-y-4 mt-4">
                  {filteredAppointments.length === 0 ? (
                    <div className="text-center py-12">
                      <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <h3 className="text-lg font-semibold">Nenhuma consulta agendada</h3>
                      <p className="text-muted-foreground mt-2">
                        Não há consultas para esta data com os filtros selecionados.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {filteredAppointments.map((apt) => {
                        const appointmentDate = parseISO(apt.date)
                        const isAppointmentToday = isToday(appointmentDate)
                        
                        return (
                          <div
                            key={apt.id}
                            className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                          >
                            <div className="flex-1 space-y-2">
                              <div className="flex items-start justify-between">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h4 className="font-semibold">{apt.patient}</h4>
                                    <Badge className={getStatusColor(apt.status)}>
                                      {apt.status === 'CONFIRMED' ? 'Confirmado' : 'Pendente'}
                                    </Badge>
                                    {apt.type === 'ONLINE' && (
                                      <Badge variant="outline" className="border-blue-200 text-blue-700">
                                        <Video className="h-3 w-3 mr-1" />
                                        Online
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                                    <User className="h-3 w-3" />
                                    {apt.professional}
                                  </p>
                                </div>
                                <div className="text-right">
                                  <div className="font-medium">
                                    {format(appointmentDate, 'HH:mm')}
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {apt.duration} min
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-4 text-sm">
                                <div className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  <span>
                                    {format(appointmentDate, "dd/MM/yyyy")}
                                    {isAppointmentToday && ' (Hoje)'}
                                    {isTomorrow(appointmentDate) && ' (Amanhã)'}
                                  </span>
                                </div>
                                
                                {apt.type === 'IN_PERSON' ? (
                                  <div className="flex items-center gap-1">
                                    <MapPin className="h-3 w-3" />
                                    <span>{apt.location}</span>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-1">
                                    <Video className="h-3 w-3" />
                                    <span>Consulta Online</span>
                                  </div>
                                )}
                              </div>

                              {apt.notes && (
                                <p className="text-sm text-muted-foreground">
                                  {apt.notes}
                                </p>
                              )}
                            </div>

                            <div className="flex gap-2 mt-3 sm:mt-0 sm:ml-4">
                              {apt.type === 'ONLINE' && apt.meetingLink && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleStartMeeting(apt.meetingLink!)}
                                >
                                  <Video className="h-4 w-4 mr-1" />
                                  Entrar
                                </Button>
                              )}
                              
                              {apt.status === 'PENDING' && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleSendReminder(apt.id)}
                                >
                                  <Calendar className="h-4 w-4 mr-1" />
                                  Lembrar
                                </Button>
                              )}
                              
                              <Button size="sm" variant="ghost">
                                Editar
                              </Button>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Integração Google Agenda */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <svg className="h-5 w-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M21.35,11.1H12.18V13.83H18.69C18.36,17.64 15.19,19.27 12.19,19.27C8.36,19.27 5,16.25 5,12C5,7.9 8.2,4.73 12.2,4.73C15.29,4.73 17.1,6.7 17.1,6.7L19,4.72C19,4.72 16.56,2 12.1,2C6.42,2 2.03,6.8 2.03,12C2.03,17.05 6.16,22 12.25,22C17.6,22 21.5,18.33 21.5,12.91C21.5,11.76 21.35,11.1 21.35,11.1V11.1Z"/>
                </svg>
                Google Agenda
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Sincronização ativa</p>
                    <p className="text-sm text-muted-foreground">
                      Última sincronização: há 5 minutos
                    </p>
                  </div>
                  <Badge className="bg-green-100 text-green-800">Ativa</Badge>
                </div>
                
                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Configurações</span>
                    <Button size="sm" variant="outline">
                      Configurar
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Sincronizar</p>
                      <p className="font-medium">Bidirecional</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Lembretes</p>
                      <p className="font-medium">1 hora antes</p>
                    </div>
                  </div>
                </div>

                <Button className="w-full" variant="outline">
                  Gerenciar Integração
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}