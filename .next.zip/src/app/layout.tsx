import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/providers/Providers'
import { Toaster } from '@/components/ui/toaster'
import { NextIntlClientProvider } from 'next-intl'
import { getMessages } from 'next-intl/server'
import { locales } from '@/lib/i18n'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'PsicoGestão - Plataforma de Gestão para Psicólogos',
  description: 'Sistema completo de gestão para psicólogos autônomos, clínicas e empresas',
  keywords: ['psicologia', 'gestão', 'agendamento', 'pacientes', 'prontuário'],
  authors: [{ name: 'PsicoGestão' }],
  creator: 'PsicoGestão',
  publisher: 'PsicoGestão',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: 'website',
    locale: 'pt_BR',
    url: 'https://psicogestao.com.br',
    title: 'PsicoGestão - Plataforma de Gestão para Psicólogos',
    description: 'Sistema completo de gestão para psicólogos autônomos, clínicas e empresas',
    siteName: 'PsicoGestão',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  twitter: {
    card: 'summary_large_image',
    title: 'PsicoGestão - Plataforma de Gestão para Psicólogos',
    description: 'Sistema completo de gestão para psicólogos autônomos, clínicas e empresas',
    creator: '@psicogestao',
  },
  verification: {
    google: 'verification_token',
    yandex: 'verification_token',
    yahoo: 'verification_token',
  },
}

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }))
}

export default async function RootLayout({
  children,
  params: { locale }
}: {
  children: React.ReactNode
  params: { locale: string }
}) {
  const messages = await getMessages()

  return (
    <html lang={locale} suppressHydrationWarning>
      <body className={inter.className}>
        <NextIntlClientProvider messages={messages}>
          <Providers>
            {children}
            <Toaster />
          </Providers>
        </NextIntlClientProvider>
      </body>
    </html>
  )
}