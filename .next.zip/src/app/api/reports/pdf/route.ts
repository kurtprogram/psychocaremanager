import { NextRequest, NextResponse } from 'next/server'
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { type, data, filters } = body

    // Criar novo documento PDF
    const pdfDoc = await PDFDocument.create()
    const page = pdfDoc.addPage([595.28, 841.89]) // A4
    const { width, height } = page.getSize()
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica)
    const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold)

    // Cabeçalho
    page.drawText('PsicoGestão - Relatório', {
      x: 50,
      y: height - 50,
      size: 20,
      font: boldFont,
      color: rgb(0.2, 0.4, 0.2),
    })

    page.drawText('Relatório Gerado em: ' + new Date().toLocaleDateString('pt-BR'), {
      x: 50,
      y: height - 80,
      size: 10,
      font,
      color: rgb(0.4, 0.4, 0.4),
    })

    // Linha divisória
    page.drawLine({
      start: { x: 50, y: height - 90 },
      end: { x: width - 50, y: height - 90 },
      thickness: 1,
      color: rgb(0.8, 0.8, 0.8),
    })

    // Conteúdo baseado no tipo
    let yPosition = height - 120
    const lineHeight = 20

    if (type === 'attendance') {
      page.drawText('Relatório de Atendimentos', {
        x: 50,
        y: yPosition,
        size: 16,
        font: boldFont,
        color: rgb(0, 0, 0),
      })
      yPosition -= 30

      // Dados de exemplo
      const reportData = [
        { period: 'Janeiro 2024', appointments: 42, revenue: 10500 },
        { period: 'Fevereiro 2024', appointments: 38, revenue: 9500 },
        { period: 'Março 2024', appointments: 45, revenue: 11250 },
      ]

      reportData.forEach(item => {
        page.drawText(`${item.period}:`, {
          x: 50,
          y: yPosition,
          size: 12,
          font: boldFont,
          color: rgb(0, 0, 0),
        })

        page.drawText(`${item.appointments} consultas • R$ ${item.revenue.toFixed(2)}`, {
          x: 200,
          y: yPosition,
          size: 12,
          font,
          color: rgb(0, 0, 0),
        })

        yPosition -= lineHeight
      })
    } else if (type === 'financial') {
      page.drawText('Relatório Financeiro', {
        x: 50,
        y: yPosition,
        size: 16,
        font: boldFont,
        color: rgb(0, 0, 0),
      })
      yPosition -= 30

      // Resumo financeiro
      const summary = {
        totalRevenue: 31250,
        pendingPayments: 1560,
        averagePerAppointment: 250,
        growth: 12.5
      }

      const summaryItems = [
        ['Receita Total:', `R$ ${summary.totalRevenue.toFixed(2)}`],
        ['Pagamentos Pendentes:', `R$ ${summary.pendingPayments.toFixed(2)}`],
        ['Média por Consulta:', `R$ ${summary.averagePerAppointment.toFixed(2)}`],
        ['Crescimento:', `${summary.growth}%`],
      ]

      summaryItems.forEach(([label, value]) => {
        page.drawText(label, {
          x: 50,
          y: yPosition,
          size: 12,
          font: boldFont,
          color: rgb(0, 0, 0),
        })

        page.drawText(value, {
          x: 250,
          y: yPosition,
          size: 12,
          font,
          color: rgb(0, 0, 0),
        })

        yPosition -= lineHeight
      })
    }

    // Rodapé
    page.drawText('© PsicoGestão - Sistema de Gestão para Psicólogos', {
      x: 50,
      y: 50,
      size: 8,
      font,
      color: rgb(0.5, 0.5, 0.5),
    })

    page.drawText('Documento gerado automaticamente. LGPD compliant.', {
      x: 50,
      y: 35,
      size: 8,
      font,
      color: rgb(0.5, 0.5, 0.5),
    })

    // Serializar PDF
    const pdfBytes = await pdfDoc.save()

    // Retornar PDF
    return new NextResponse(Buffer.from(pdfBytes), {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=\"relatorio-${type}-${new Date().getTime()}.pdf\"`,
      },
    })

  } catch (error) {
    console.error('Error generating PDF:', error)
    return NextResponse.json(
      { error: 'Erro ao gerar relatório PDF' },
      { status: 500 }
    )
  }
}