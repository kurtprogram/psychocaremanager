import * as React from 'react'

export function Select<T extends string = string>({ children, value, onValueChange, disabled, ...props }: { value?: T; onValueChange?: (value: T) => void; disabled?: boolean } & React.HTMLAttributes<HTMLDivElement>) {
  // This simple wrapper stores the value as a data attribute so callers can read it if needed
  return (
    <div {...props} data-value={value} aria-disabled={disabled}>
      {children}
    </div>
  )
}

export function SelectTrigger({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button {...props}>{children}</button>
}

export function SelectContent({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props}>{children}</div>
}

export function SelectItem({ children, value, ...props }: { value: string } & React.HTMLAttributes<HTMLDivElement>) {
  // expose value as data attribute so it can be read by parent logic
  return (
    <div {...props} data-value={value}>
      {children}
    </div>
  )
}

export function SelectValue({ children, placeholder, ...props }: { placeholder?: string } & React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props}>{children ?? placeholder}</div>
}
