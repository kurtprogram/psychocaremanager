import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { prisma } from '@/lib/prisma'
import { authConfig } from '@/lib/auth'

// Configuração do Twilio (WhatsApp Business API)
const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN
const TWILIO_WHATSAPP_NUMBER = process.env.TWILIO_WHATSAPP_NUMBER

async function sendWhatsAppMessage(to: string, message: string) {
  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_WHATSAPP_NUMBER) {
    console.warn('Twilio credentials not configured')
    return { success: false, message: 'Twilio não configurado' }
  }

  try {
    // Em produção, usar Twilio real
    // const client = require('twilio')(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
    
    // const result = await client.messages.create({
    //   from: `whatsapp:${TWILIO_WHATSAPP_NUMBER}`,
    //   to: `whatsapp:${to}`,
    //   body: message,
    // });

    // Simulação para desenvolvimento
    console.log('WhatsApp Message (simulated):', {
      to,
      message,
      timestamp: new Date().toISOString(),
    })

    return { 
      success: true, 
      message: 'Mensagem enviada com sucesso',
      sid: 'simulated_' + Date.now()
    }
  } catch (error) {
    console.error('Error sending WhatsApp message:', error)
    return { 
      success: false, 
      message: 'Erro ao enviar mensagem' 
    }
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const body = await req.json()
    const { patientId, template, customMessage, appointmentId } = body

    // Buscar paciente
    const patient = await prisma.patient.findUnique({
      where: {
        id: patientId,
        organizationId: session.user.organizationId,
      },
    })

    if (!patient) {
      return NextResponse.json(
        { error: 'Paciente não encontrado' },
        { status: 404 }
      )
    }

    if (!patient.whatsapp) {
      return NextResponse.json(
        { error: 'Paciente não possui WhatsApp cadastrado' },
        { status: 400 }
      )
    }

    // Buscar template ou usar mensagem personalizada
    let message = customMessage

    if (!message && template) {
      const templateData = await prisma.whatsAppTemplate.findFirst({
        where: {
          organizationId: session.user.organizationId,
          name: template,
          isActive: true,
        },
      })

      if (templateData) {
        message = templateData.body
        
        // Substituir variáveis se for appointment
        if (appointmentId) {
          const appointment = await prisma.appointment.findUnique({
            where: { id: appointmentId },
            include: { professional: true },
          })

          if (appointment) {
            message = message
              .replace('{patient_name}', patient.fullName)
              .replace('{professional_name}', appointment.professional.name)
              .replace('{appointment_date}', appointment.startTime.toLocaleDateString('pt-BR'))
              .replace('{appointment_time}', appointment.startTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }))
          }
        }
      }
    }

    if (!message) {
      return NextResponse.json(
        { error: 'Nenhuma mensagem especificada' },
        { status: 400 }
      )
    }

    // Enviar mensagem
    const result = await sendWhatsAppMessage(patient.whatsapp, message)

    if (!result.success) {
      return NextResponse.json(
        { error: result.message },
        { status: 500 }
      )
    }

    // Registrar notificação
    await prisma.notification.create({
      data: {
        organizationId: session.user.organizationId,
        patientId: patient.id,
        type: 'WHATSAPP_MESSAGE',
        channel: 'WHATSAPP',
        title: 'Mensagem WhatsApp',
        message: message.substring(0, 100) + (message.length > 100 ? '...' : ''),
        status: 'SENT',
        sentAt: new Date(),
        data: {
          to: patient.whatsapp,
          template,
          result,
        },
      },
    })

    // Log de auditoria
    await prisma.auditLog.create({
      data: {
        organizationId: session.user.organizationId,
        userId: session.user.id,
        userEmail: session.user.email!,
        userName: session.user.name!,
        action: 'WHATSAPP_SEND',
        entityType: 'PATIENT',
        entityId: patient.id,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    return NextResponse.json({
      success: true,
      message: 'Mensagem enviada com sucesso',
      result,
    })

  } catch (error) {
    console.error('Error sending WhatsApp:', error)
    return NextResponse.json(
      { error: 'Erro ao enviar mensagem' },
      { status: 500 }
    )
  }
}