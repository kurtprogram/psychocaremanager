import * as React from 'react'

export function Alert({ children, variant, ...props }: { variant?: string } & React.HTMLAttributes<HTMLDivElement>) {
  return <div data-variant={variant} {...props}>{children}</div>
}

export function AlertDescription({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props}>{children}</div>
}
