import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { prisma } from '@/lib/prisma'
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib'
import { authConfig } from '@/lib/auth'
import { format, subMonths } from 'date-fns'
import { ptBR } from 'date-fns/locale'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const body = await req.json()
    const { type, startDate, endDate, patientId, professionalId } = body

    // Buscar dados do banco
    let reportData: any = {}
    let title = ''

    if (type === 'attendance') {
      title = 'Relatório de Atendimentos'
      
      const appointments: any[] = await prisma.appointment.findMany({
        where: {
          organizationId: session.user.organizationId,
          startTime: {
            gte: new Date(startDate),
            lte: new Date(endDate),
          },
          deletedAt: null,
        },
        include: {
          patient: {
            select: {
              fullName: true,
            },
          },
          professional: {
            select: {
              name: true,
            },
          },
        },
        orderBy: {
          startTime: 'asc',
        },
      })

      const stats = {
        totalAppointments: appointments.length,
        completed: appointments.filter((a: any) => a.status === 'COMPLETED').length,
        cancelled: appointments.filter((a: any) => a.status === 'CANCELLED').length,
        byProfessional: appointments.reduce((acc: Record<string, number>, apt: any) => {
          const name = apt.professional.name
          acc[name] = (acc[name] || 0) + 1
          return acc
        }, {} as Record<string, number>),
      }

      reportData = { appointments, stats }

    } else if (type === 'financial') {
      title = 'Relatório Financeiro'
      
      const payments: any[] = await prisma.payment.findMany({
        where: {
          organizationId: session.user.organizationId,
          dueDate: {
            gte: new Date(startDate),
            lte: new Date(endDate),
          },
          deletedAt: null,
        },
        include: {
          patient: {
            select: {
              fullName: true,
            },
          },
        },
        orderBy: {
          dueDate: 'asc',
        },
      })

      const stats = {
        totalRevenue: payments.reduce((sum: number, p: any) => sum + Number(p.amount), 0),
        pending: payments.filter((p: any) => p.status === 'PENDING').reduce((sum: number, p: any) => sum + Number(p.amount), 0),
        paid: payments.filter((p: any) => p.status === 'PAID').reduce((sum: number, p: any) => sum + Number(p.amount), 0),
        byMethod: payments.reduce((acc: Record<string, number>, p: any) => {
          acc[p.method] = (acc[p.method] || 0) + Number(p.amount)
          return acc
        }, {} as Record<string, number>),
      }

      reportData = { payments, stats }
    }

    // Gerar PDF
    const pdfDoc = await PDFDocument.create()
    const page = pdfDoc.addPage([595.28, 841.89]) // A4
    const { width, height } = page.getSize()
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica)
    const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold)

    // Cabeçalho
    page.drawText('PsicoGestão', {
      x: 50,
      y: height - 50,
      size: 24,
      font: boldFont,
      color: rgb(0.2, 0.4, 0.2),
    })

    page.drawText(title, {
      x: 50,
      y: height - 80,
      size: 18,
      font: boldFont,
      color: rgb(0, 0, 0),
    })

    page.drawText(`Período: ${format(new Date(startDate), 'dd/MM/yyyy', { locale: ptBR })} - ${format(new Date(endDate), 'dd/MM/yyyy', { locale: ptBR })}`, {
      x: 50,
      y: height - 110,
      size: 12,
      font,
      color: rgb(0.4, 0.4, 0.4),
    })

    page.drawText(`Gerado em: ${format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}`, {
      x: 50,
      y: height - 125,
      size: 10,
      font,
      color: rgb(0.4, 0.4, 0.4),
    })

    // Linha divisória
    page.drawLine({
      start: { x: 50, y: height - 140 },
      end: { x: width - 50, y: height - 140 },
      thickness: 1,
      color: rgb(0.8, 0.8, 0.8),
    })

    // Conteúdo
    let yPosition = height - 170

    if (type === 'attendance') {
      // Estatísticas
      page.drawText('Estatísticas:', {
        x: 50,
        y: yPosition,
        size: 14,
        font: boldFont,
        color: rgb(0, 0, 0),
      })
      yPosition -= 25

      const statsItems = [
        ['Total de Consultas:', reportData.stats.totalAppointments.toString()],
        ['Realizadas:', reportData.stats.completed.toString()],
        ['Canceladas:', reportData.stats.cancelled.toString()],
        ['Taxa de Comparecimento:', `${reportData.stats.totalAppointments > 0 ? Math.round((reportData.stats.completed / reportData.stats.totalAppointments) * 100) : 0}%`],
      ]

      statsItems.forEach(([label, value]) => {
        page.drawText(label, {
          x: 50,
          y: yPosition,
          size: 12,
          font,
          color: rgb(0, 0, 0),
        })

        page.drawText(value, {
          x: 200,
          y: yPosition,
          size: 12,
          font: boldFont,
          color: rgb(0, 0, 0),
        })

        yPosition -= 20
      })

      yPosition -= 20

      // Por profissional
      page.drawText('Consultas por Profissional:', {
        x: 50,
        y: yPosition,
        size: 14,
        font: boldFont,
        color: rgb(0, 0, 0),
      })
      yPosition -= 25

      Object.entries(reportData.stats.byProfessional).forEach(([name, count]) => {
        page.drawText(name, {
          x: 50,
          y: yPosition,
          size: 12,
          font,
          color: rgb(0, 0, 0),
        })

        page.drawText(`${count} consultas`, {
          x: 200,
          y: yPosition,
          size: 12,
          font: boldFont,
          color: rgb(0, 0, 0),
        })

        yPosition -= 20
      })

    } else if (type === 'financial') {
      // Resumo financeiro
      page.drawText('Resumo Financeiro:', {
        x: 50,
        y: yPosition,
        size: 14,
        font: boldFont,
        color: rgb(0, 0, 0),
      })
      yPosition -= 25

      const financialItems = [
        ['Receita Total:', `R$ ${reportData.stats.totalRevenue.toFixed(2)}`],
        ['Recebido:', `R$ ${reportData.stats.paid.toFixed(2)}`],
        ['Pendente:', `R$ ${reportData.stats.pending.toFixed(2)}`],
        ['Taxa de Recebimento:', `${reportData.stats.totalRevenue > 0 ? Math.round((reportData.stats.paid / reportData.stats.totalRevenue) * 100) : 0}%`],
      ]

      financialItems.forEach(([label, value]) => {
        page.drawText(label, {
          x: 50,
          y: yPosition,
          size: 12,
          font,
          color: rgb(0, 0, 0),
        })

        page.drawText(value, {
          x: 200,
          y: yPosition,
          size: 12,
          font: boldFont,
          color: rgb(0, 0, 0),
        })

        yPosition -= 20
      })

      yPosition -= 20

      // Por método de pagamento
      page.drawText('Por Método de Pagamento:', {
        x: 50,
        y: yPosition,
        size: 14,
        font: boldFont,
        color: rgb(0, 0, 0),
      })
      yPosition -= 25

      Object.entries(reportData.stats.byMethod).forEach(([method, amount]) => {
        page.drawText(method, {
          x: 50,
          y: yPosition,
          size: 12,
          font,
          color: rgb(0, 0, 0),
        })

        page.drawText(`R$ ${Number(amount).toFixed(2)}`, {
          x: 200,
          y: yPosition,
          size: 12,
          font: boldFont,
          color: rgb(0, 0, 0),
        })

        yPosition -= 20
      })
    }

    // Rodapé
    page.drawText('© PsicoGestão - Sistema de Gestão para Psicólogos', {
      x: 50,
      y: 50,
      size: 8,
      font,
      color: rgb(0.5, 0.5, 0.5),
    })

    page.drawText('Documento gerado automaticamente. LGPD compliant.', {
      x: 50,
      y: 35,
      size: 8,
      font,
      color: rgb(0.5, 0.5, 0.5),
    })

    // Serializar PDF
    const pdfBytes = await pdfDoc.save()

    // Retornar PDF
    return new NextResponse(Buffer.from(pdfBytes), {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename=\"relatorio-${type}-${Date.now()}.pdf\"`,
      },
    })

  } catch (error) {
    console.error('Error generating report:', error)
    return NextResponse.json(
      { error: 'Erro ao gerar relatório' },
      { status: 500 }
    )
  }
}