'use client'

import { useState, useEffect } from 'react'
import { Target, Trophy, Calendar, CheckCircle, Star, Award, TrendingUp } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/useToast'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

interface Mission {
  id: string
  title: string
  description: string
  type: 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'SPECIAL'
  difficulty: number
  points: number
  progress: number
  isCompleted: boolean
  completedAt?: string
  dueDate?: string
  tasks: Array<{
    id: string
    description: string
    completed: boolean
  }>
}

export default function MissoesPage() {
  const { toast } = useToast()
  const [missions, setMissions] = useState<Mission[]>([])
  const [loading, setLoading] = useState(true)
  const [points, setPoints] = useState(0)
  const [streak, setStreak] = useState(0)

  useEffect(() => {
    loadMissions()
  }, [])

  const loadMissions = async () => {
    try {
      // Em produção, buscar da API
      const mockMissions: Mission[] = [
        {
          id: '1',
          title: 'Diário de Emoções',
          description: 'Registre suas emoções por 7 dias consecutivos',
          type: 'DAILY',
          difficulty: 2,
          points: 100,
          progress: 85,
          isCompleted: false,
          tasks: [
            { id: '1', description: 'Dia 1: Identificar emoções', completed: true },
            { id: '2', description: 'Dia 2: Registrar intensidade', completed: true },
            { id: '3', description: 'Dia 3: Notar gatilhos', completed: true },
            { id: '4', description: 'Dia 4: Padrões emocionais', completed: true },
            { id: '5', description: 'Dia 5: Estratégias de regulação', completed: true },
            { id: '6', description: 'Dia 6: Auto-compassão', completed: false },
            { id: '7', description: 'Dia 7: Revisão da semana', completed: false },
          ],
        },
        {
          id: '2',
          title: 'Exercícios de Respiração',
          description: 'Complete 10 sessões de respiração consciente',
          type: 'WEEKLY',
          difficulty: 1,
          points: 50,
          progress: 40,
          isCompleted: false,
          tasks: [
            { id: '1', description: 'Sessão 1: 5 minutos', completed: true },
            { id: '2', description: 'Sessão 2: 5 minutos', completed: true },
            { id: '3', description: 'Sessão 3: 5 minutos', completed: true },
            { id: '4', description: 'Sessão 4: 5 minutos', completed: true },
            { id: '5', description: 'Sessão 5: 5 minutos', completed: false },
          ],
        },
        {
          id: '3',
          title: 'Reconhecimento de Pensamentos',
          description: 'Identifique 20 pensamentos automáticos',
          type: 'MONTHLY',
          difficulty: 3,
          points: 200,
          progress: 60,
          isCompleted: false,
          dueDate: '2024-01-31',
          tasks: [
            { id: '1', description: 'Identificar pensamentos negativos', completed: true },
            { id: '2', description: 'Classificar distorções cognitivas', completed: true },
            { id: '3', description: 'Questionar evidências', completed: true },
            { id: '4', description: 'Gerar pensamentos alternativos', completed: false },
          ],
        },
      ]

      setMissions(mockMissions)
      setPoints(225)
      setStreak(7)
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar as missões',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const completeTask = async (missionId: string, taskId: string) => {
    setMissions(prev => prev.map(mission => {
      if (mission.id === missionId) {
        const updatedTasks = mission.tasks.map(task =>
          task.id === taskId ? { ...task, completed: true } : task
        )
        
        const completedTasks = updatedTasks.filter(t => t.completed).length
        const progress = (completedTasks / mission.tasks.length) * 100
        const isCompleted = progress >= 100
        
        if (isCompleted && !mission.isCompleted) {
          const newPoints = points + mission.points
          setPoints(newPoints)
          
          toast({
            title: 'Missão Concluída! 🎉',
            description: `+${mission.points} pontos adquiridos!`,
          })
        }
        
        return {
          ...mission,
          tasks: updatedTasks,
          progress,
          isCompleted,
          ...(isCompleted && !mission.completedAt && {
            completedAt: new Date().toISOString(),
          }),
        }
      }
      return mission
    }))
  }

  const getDifficultyColor = (difficulty: number) => {
    switch (difficulty) {
      case 1: return 'bg-green-100 text-green-800'
      case 2: return 'bg-amber-100 text-amber-800'
      case 3: return 'bg-orange-100 text-orange-800'
      case 4: return 'bg-red-100 text-red-800'
      case 5: return 'bg-purple-100 text-purple-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getDifficultyLabel = (difficulty: number) => {
    switch (difficulty) {
      case 1: return 'Fácil'
      case 2: return 'Médio'
      case 3: return 'Difícil'
      case 4: return 'Especialista'
      case 5: return 'Mestre'
      default: return 'Desconhecido'
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Minhas Missões</h1>
          <p className="text-muted-foreground">
            Complete missões para evoluir na sua jornada terapêutica
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-amber-100 text-amber-800">
            <Star className="h-3 w-3 mr-1" />
            {points} pontos
          </Badge>
          <Badge className="bg-blue-100 text-blue-800">
            <TrendingUp className="h-3 w-3 mr-1" />
            Sequência: {streak} dias
          </Badge>
        </div>
      </div>

      {/* Progresso Geral */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Missões Concluídas</CardTitle>
            <Trophy className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {missions.filter(m => m.isCompleted).length}/{missions.length}
            </div>
            <Progress 
              value={(missions.filter(m => m.isCompleted).length / missions.length) * 100} 
              className="h-2 mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pontos Totais</CardTitle>
            <Award className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{points}</div>
            <p className="text-xs text-muted-foreground">
              {missions.filter(m => m.isCompleted).reduce((sum, m) => sum + m.points, 0)} pontos ganhos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Nível de Engajamento</CardTitle>
            <Target className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(missions.reduce((sum, m) => sum + m.progress, 0) / missions.length)}%
            </div>
            <p className="text-xs text-muted-foreground">
              Baseado no progresso das missões
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Lista de Missões */}
      <div className="space-y-4">
        {missions.map((mission) => (
          <Card key={mission.id} className={mission.isCompleted ? 'border-green-200 bg-green-50' : ''}>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    {mission.title}
                    {mission.isCompleted && (
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Concluída
                      </Badge>
                    )}
                  </CardTitle>
                  <CardDescription className="mt-1">
                    {mission.description}
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={getDifficultyColor(mission.difficulty)}>
                    {getDifficultyLabel(mission.difficulty)}
                  </Badge>
                  <Badge variant="outline" className="border-amber-200 text-amber-700">
                    <Star className="h-3 w-3 mr-1" />
                    {mission.points} pts
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Progresso */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progresso</span>
                    <span>{Math.round(mission.progress)}%</span>
                  </div>
                  <Progress value={mission.progress} className="h-2" />
                </div>

                {/* Tarefas */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Tarefas:</h4>
                  <div className="space-y-2">
                    {mission.tasks.map((task) => (
                      <div
                        key={task.id}
                        className="flex items-center justify-between p-2 border rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                            task.completed 
                              ? 'bg-green-100 text-green-600' 
                              : 'bg-gray-100 text-gray-400'
                          }`}>
                            {task.completed ? (
                              <CheckCircle className="h-4 w-4" />
                            ) : (
                              <div className="w-2 h-2 rounded-full bg-gray-400" />
                            )}
                          </div>
                          <span className={task.completed ? 'line-through text-muted-foreground' : ''}>
                            {task.description}
                          </span>
                        </div>
                        {!task.completed && !mission.isCompleted && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => completeTask(mission.id, task.id)}
                          >
                            Concluir
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Informações Adicionais */}
                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                  {mission.dueDate && (
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>Prazo: {format(new Date(mission.dueDate), 'dd/MM/yyyy', { locale: ptBR })}</span>
                    </div>
                  )}
                  {mission.completedAt && (
                    <div className="flex items-center gap-1">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>Concluída em: {format(new Date(mission.completedAt), 'dd/MM/yyyy', { locale: ptBR })}</span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Missões Concluídas */}
      {missions.filter(m => m.isCompleted).length > 0 && (
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <Trophy className="h-5 w-5" />
              Conquistas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {missions
                .filter(m => m.isCompleted)
                .map((mission) => (
                  <div
                    key={mission.id}
                    className="flex flex-col items-center p-4 border border-green-200 rounded-lg bg-white"
                  >
                    <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-3">
                      <Trophy className="h-6 w-6 text-green-600" />
                    </div>
                    <h4 className="font-semibold text-center">{mission.title}</h4>
                    <p className="text-sm text-muted-foreground text-center mt-1">
                      +{mission.points} pontos
                    </p>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}