'use client'

import { useState, useEffect } from 'react'
import { X, Loader2, Calendar, Clock, User, MapPin, Video, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { useToast } from '@/hooks/useToast'

interface AppointmentFormProps {
  onSubmit: (data: any) => Promise<void>
  onCancel: () => void
  initialData?: any
  patients: Array<{ id: string; fullName: string }>
  professionals: Array<{ id: string; name: string }>
}

export default function AppointmentForm({ 
  onSubmit, 
  onCancel, 
  initialData,
  patients = [],
  professionals = []
}: AppointmentFormProps) {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    patientId: initialData?.patientId || '',
    professionalId: initialData?.professionalId || '',
    title: initialData?.title || '',
    description: initialData?.description || '',
    startTime: initialData?.startTime ? new Date(initialData.startTime).toISOString().slice(0, 16) : '',
    endTime: initialData?.endTime ? new Date(initialData.endTime).toISOString().slice(0, 16) : '',
    type: initialData?.type || 'IN_PERSON',
    location: initialData?.location || '',
    meetingLink: initialData?.meetingLink || '',
    notes: initialData?.notes || '',
    sendReminder: true,
  })

  useEffect(() => {
    if (initialData?.type === 'ONLINE' && !formData.meetingLink) {
      setFormData(prev => ({
        ...prev,
        meetingLink: `https://meet.google.com/${Math.random().toString(36).substr(2, 9)}`
      }))
    }
  }, [formData.type, initialData])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validações
    if (!formData.patientId || !formData.professionalId) {
      toast({
        title: 'Erro',
        description: 'Selecione paciente e profissional',
        variant: 'destructive',
      })
      return
    }

    if (!formData.startTime || !formData.endTime) {
      toast({
        title: 'Erro',
        description: 'Informe data e hora',
        variant: 'destructive',
      })
      return
    }

    if (formData.type === 'IN_PERSON' && !formData.location) {
      toast({
        title: 'Erro',
        description: 'Informe o local da consulta',
        variant: 'destructive',
      })
      return
    }

    if (formData.type === 'ONLINE' && !formData.meetingLink) {
      toast({
        title: 'Erro',
        description: 'Informe o link da reunião',
        variant: 'destructive',
      })
      return
    }

    setIsLoading(true)
    try {
      await onSubmit({
        ...formData,
        startTime: new Date(formData.startTime).toISOString(),
        endTime: new Date(formData.endTime).toISOString(),
      })
    } finally {
      setIsLoading(false)
    }
  }

  const calculateEndTime = (startTime: string, duration: number) => {
    if (!startTime) return ''
    const start = new Date(startTime)
    const end = new Date(start.getTime() + duration * 60000)
    return end.toISOString().slice(0, 16)
  }

  const handleDurationChange = (duration: number) => {
    if (formData.startTime) {
      setFormData(prev => ({
        ...prev,
        endTime: calculateEndTime(prev.startTime, duration)
      }))
    }
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">
          {initialData ? 'Editar Consulta' : 'Nova Consulta'}
        </h2>
        <Button variant="ghost" size="icon" onClick={onCancel}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Informações Básicas */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="patientId">Paciente *</Label>
            <Select
              value={formData.patientId}
              onValueChange={(value) => handleSelectChange('patientId', value)}
              disabled={isLoading}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o paciente" />
              </SelectTrigger>
              <SelectContent>
                {patients.map(patient => (
                  <SelectItem key={patient.id} value={patient.id}>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      {patient.fullName}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="professionalId">Profissional *</Label>
            <Select
              value={formData.professionalId}
              onValueChange={(value) => handleSelectChange('professionalId', value)}
              disabled={isLoading}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o profissional" />
              </SelectTrigger>
              <SelectContent>
                {professionals.map(prof => (
                  <SelectItem key={prof.id} value={prof.id}>
                    {prof.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Título *</Label>
            <Input
              id="title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
              disabled={isLoading}
              placeholder="Ex: Consulta Inicial"
            />
          </div>

          <div className="space-y-2">
            <Label>Duração</Label>
            <div className="flex gap-2">
              {[30, 50, 60, 90].map(minutes => (
                <Button
                  key={minutes}
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleDurationChange(minutes)}
                  disabled={!formData.startTime || isLoading}
                >
                  {minutes} min
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Data e Hora */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="startTime">Data e Hora Início *</Label>
            <div className="relative">
              <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="startTime"
                name="startTime"
                type="datetime-local"
                value={formData.startTime}
                onChange={handleChange}
                required
                disabled={isLoading}
                className="pl-10"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="endTime">Data e Hora Fim *</Label>
            <div className="relative">
              <Clock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="endTime"
                name="endTime"
                type="datetime-local"
                value={formData.endTime}
                onChange={handleChange}
                required
                disabled={isLoading}
                className="pl-10"
              />
            </div>
          </div>
        </div>

        {/* Tipo de Consulta */}
        <div>
          <Label>Tipo de Consulta *</Label>
          <div className="flex gap-4 mt-2">
            <Button
              type="button"
              variant={formData.type === 'IN_PERSON' ? 'default' : 'outline'}
              onClick={() => handleSelectChange('type', 'IN_PERSON')}
              disabled={isLoading}
              className="flex-1"
            >
              <MapPin className="h-4 w-4 mr-2" />
              Presencial
            </Button>
            <Button
              type="button"
              variant={formData.type === 'ONLINE' ? 'default' : 'outline'}
              onClick={() => handleSelectChange('type', 'ONLINE')}
              disabled={isLoading}
              className="flex-1"
            >
              <Video className="h-4 w-4 mr-2" />
              Online
            </Button>
          </div>
        </div>

        {/* Local/Link */}
        {formData.type === 'IN_PERSON' ? (
          <div className="space-y-2">
            <Label htmlFor="location">Local da Consulta *</Label>
            <Input
              id="location"
              name="location"
              value={formData.location}
              onChange={handleChange}
              required
              disabled={isLoading}
              placeholder="Ex: Consultório Central, Sala 2"
            />
          </div>
        ) : (
          <div className="space-y-2">
            <Label htmlFor="meetingLink">Link da Reunião *</Label>
            <Input
              id="meetingLink"
              name="meetingLink"
              value={formData.meetingLink}
              onChange={handleChange}
              required
              disabled={isLoading}
              placeholder="https://meet.google.com/abc-defg-hij"
            />
          </div>
        )}

        {/* Descrição e Notas */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="description">Descrição</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              disabled={isLoading}
              rows={3}
              placeholder="Descrição da consulta..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Observações</Label>
            <Textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              disabled={isLoading}
              rows={2}
              placeholder="Observações importantes..."
            />
          </div>
        </div>

        {/* Configurações */}
        <div className="flex items-center justify-between p-4 border rounded-lg">
          <div className="space-y-0.5">
            <Label>Enviar Lembrete</Label>
            <p className="text-sm text-muted-foreground">
              Enviar lembrete por WhatsApp 1 hora antes
            </p>
          </div>
          <Switch
            checked={formData.sendReminder}
            onCheckedChange={(checked: boolean) => 
              setFormData(prev => ({ ...prev, sendReminder: checked }))
            }
            disabled={isLoading}
          />
        </div>

        {/* Botões */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
            Cancelar
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {initialData ? 'Atualizar Consulta' : 'Agendar Consulta'}
          </Button>
        </div>
      </form>
    </div>
  )
}