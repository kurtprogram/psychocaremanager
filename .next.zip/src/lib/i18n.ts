import { getRequestConfig } from 'next-intl/server'
import { cookies, headers } from 'next/headers'

const locales = ['pt', 'en', 'es'] as const
export type Locale = typeof locales[number]
export { locales }

export default getRequestConfig(async () => {
  // Try to get locale from cookie
  const cookieStore = await cookies()
  const localeCookie = cookieStore.get('NEXT_LOCALE')?.value as Locale
  
  // Try to get from Accept-Language header
  const headersList = await headers()
  const acceptLanguage = headersList.get('accept-language')
  let browserLocale: Locale = 'pt'
  
  if (acceptLanguage) {
    if (acceptLanguage.includes('en')) browserLocale = 'en'
    else if (acceptLanguage.includes('es')) browserLocale = 'es'
  }
  
  const locale = localeCookie || browserLocale
  
  return {
    locale,
    messages: (await import(`../../public/locales/${locale}.json`)).default,
    timeZone: 'America/Sao_Paulo',
  }
})

export function getTranslations() {
  return {
    pt: () => import('../../public/locales/pt.json'),
    en: () => import('../../public/locales/en.json'),
    es: () => import('../../public/locales/es.json'),
  }
}