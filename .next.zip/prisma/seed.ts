import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Iniciando seed do banco de dados...')

  // Criar plano padrão
  const individualPlan = await prisma.organization.upsert({
    where: { id: 'default-individual' },
    update: {},
    create: {
      id: 'default-individual',
      name: 'Plano Individual Padrão',
      type: 'INDIVIDUAL',
      status: 'ACTIVE',
      maxProfessionals: 1,
      maxPatients: 100,
      trialEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 dias
      settings: {
        whatsappEnabled: true,
        googleCalendarEnabled: true,
        multiLanguage: true,
      }
    }
  })

  // Criar usuário administrador padrão
  const hashedPassword = await bcrypt.hash('admin123', 10)
  
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@psicogestao.com' },
    update: {},
    create: {
      email: 'admin@psicogestao.com',
      name: 'Administrador',
      role: 'SUPER_ADMIN',
      passwordHash: hashedPassword,
      organizationId: individualPlan.id,
      phone: '+5511999999999',
      whatsapp: '+5511999999999',
    }
  })

  // Criar psicólogo de exemplo
  const psychologistUser = await prisma.user.upsert({
    where: { email: 'psicologa@exemplo.com' },
    update: {},
    create: {
      email: 'psicologa@exemplo.com',
      name: 'Dra. Maria Silva',
      role: 'PSYCHOLOGIST',
      passwordHash: await bcrypt.hash('senha123', 10),
      organizationId: individualPlan.id,
      phone: '+5511988888888',
      whatsapp: '+5511988888888',
      specialty: 'Psicologia Clínica',
      licenseNumber: 'CRP-12345/SP',
      bio: 'Especialista em terapia cognitivo-comportamental',
    }
  })

  // Criar paciente de exemplo
  const patient = await prisma.patient.create({
    data: {
      organizationId: individualPlan.id,
      fullName: 'João da Silva',
      email: 'joao@exemplo.com',
      phone: '+5511977777777',
      whatsapp: '+5511977777777',
      dateOfBirth: new Date('1990-05-15'),
      gender: 'Masculino',
      cpf: '123.456.789-00',
      address: 'Rua das Flores, 123',
      city: 'São Paulo',
      state: 'SP',
      emergencyContactName: 'Maria da Silva',
      emergencyContactPhone: '+5511966666666',
      status: 'ACTIVE',
    }
  })

  // Criar consulta de exemplo
  const appointment = await prisma.appointment.create({
    data: {
      organizationId: individualPlan.id,
      professionalId: psychologistUser.id,
      patientId: patient.id,
      title: 'Consulta Inicial',
      description: 'Primeira sessão de avaliação',
      startTime: new Date(Date.now() + 24 * 60 * 60 * 1000), // Amanhã
      endTime: new Date(Date.now() + 24 * 60 * 60 * 1000 + 50 * 60 * 1000), // 50 minutos depois
      type: 'IN_PERSON',
      status: 'SCHEDULED',
      location: 'Consultório Central',
    }
  })

  // Criar templates de WhatsApp
  const whatsappTemplates = await prisma.whatsAppTemplate.createMany({
    data: [
      {
        organizationId: individualPlan.id,
        name: 'Lembrete de Consulta',
        category: 'APPOINTMENT_REMINDER',
        language: 'pt',
        body: 'Olá {patient_name}! Lembrete: sua consulta com {professional_name} está agendada para {appointment_date} às {appointment_time}.',
        footer: 'Para reagendar ou cancelar, entre em contato.',
        isActive: true,
      },
      {
        organizationId: individualPlan.id,
        name: 'Confirmação de Consulta',
        category: 'APPOINTMENT_CONFIRMATION',
        language: 'pt',
        body: 'Olá {patient_name}! Sua consulta com {professional_name} foi confirmada para {appointment_date} às {appointment_time}.',
        footer: 'Obrigado por escolher nossos serviços.',
        isActive: true,
      },
      {
        organizationId: individualPlan.id,
        name: 'Boas-vindas',
        category: 'WELCOME',
        language: 'pt',
        body: 'Olá {patient_name}! Seja bem-vindo(a) ao nosso sistema. Estamos aqui para ajudar você em sua jornada.',
        footer: 'Qualquer dúvida, entre em contato.',
        isActive: true,
      },
    ]
  })

  console.log('✅ Seed concluído com sucesso!')
  console.log('👤 Admin:', adminUser.email)
  console.log('👩‍⚕️ Psicóloga:', psychologistUser.email)
  console.log('👤 Paciente:', patient.fullName)
  console.log('📅 Consulta:', appointment.title)
}

main()
  .catch((e) => {
    console.error('❌ Erro no seed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })