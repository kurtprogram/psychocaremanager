import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import { authConfig } from '@/lib/auth'

const appointmentSchema = z.object({
  patientId: z.string(),
  professionalId: z.string(),
  title: z.string().min(3, 'Título muito curto'),
  description: z.string().optional(),
  startTime: z.string().datetime(),
  endTime: z.string().datetime(),
  type: z.enum(['IN_PERSON', 'ONLINE']),
  location: z.string().optional(),
  meetingLink: z.string().url().optional().or(z.literal('')),
  notes: z.string().optional(),
})

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(req.url)
    const startDate = searchParams.get('start')
    const endDate = searchParams.get('end')

    const appointments = await prisma.appointment.findMany({
      where: {
        organizationId: session.user.organizationId,
        deletedAt: null,
        ...(startDate && endDate && {
          startTime: {
            gte: new Date(startDate),
            lte: new Date(endDate),
          },
        }),
      },
      include: {
        patient: {
          select: {
            id: true,
            fullName: true,
            phone: true,
          },
        },
        professional: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
      orderBy: {
        startTime: 'asc',
      },
    })

    return NextResponse.json(appointments)
  } catch (error) {
    console.error('Error fetching appointments:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar consultas' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const body = await req.json()
    
    // Validar dados
    const validated = appointmentSchema.parse(body)

    // Verificar conflito de horário
    const conflictingAppointment = await prisma.appointment.findFirst({
      where: {
        organizationId: session.user.organizationId,
        professionalId: validated.professionalId,
        OR: [
          {
            startTime: { lt: new Date(validated.endTime) },
            endTime: { gt: new Date(validated.startTime) },
          },
        ],
        status: { in: ['SCHEDULED', 'CONFIRMED'] },
        deletedAt: null,
      },
    })

    if (conflictingAppointment) {
      return NextResponse.json(
        { error: 'Horário já ocupado para este profissional' },
        { status: 400 }
      )
    }

    // Criar consulta
    const appointment = await prisma.appointment.create({
      data: {
        organizationId: session.user.organizationId,
        patientId: validated.patientId,
        professionalId: validated.professionalId,
        title: validated.title,
        description: validated.description,
        startTime: new Date(validated.startTime),
        endTime: new Date(validated.endTime),
        type: validated.type,
        location: validated.type === 'IN_PERSON' ? validated.location : null,
        meetingLink: validated.type === 'ONLINE' ? validated.meetingLink : null,
        notes: validated.notes,
        status: 'SCHEDULED',
      },
      include: {
        patient: true,
        professional: true,
      },
    })

    // Criar log de auditoria
    await prisma.auditLog.create({
      data: {
        organizationId: session.user.organizationId,
        userId: session.user.id,
        userEmail: session.user.email!,
        userName: session.user.name!,
        action: 'CREATE',
        entityType: 'APPOINTMENT',
        entityId: appointment.id,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    // Criar notificação para lembrete
    await prisma.notification.create({
      data: {
        organizationId: session.user.organizationId,
        patientId: appointment.patientId,
        type: 'APPOINTMENT_SCHEDULED',
        channel: 'WHATSAPP',
        title: 'Consulta Agendada',
        message: `Sua consulta com ${appointment.professional.name} foi agendada para ${appointment.startTime.toLocaleDateString('pt-BR')} às ${appointment.startTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}.`,
        status: 'PENDING',
      },
    })

    return NextResponse.json({
      success: true,
      appointment,
    })

  } catch (error: any) {
    console.error('Error creating appointment:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Erro ao criar consulta' },
      { status: 500 }
    )
  }
}