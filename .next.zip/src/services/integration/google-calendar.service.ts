import { google } from 'googleapis'
import { OAuth2Client } from 'google-auth-library'
import { prisma } from '@/lib/prisma'

class GoogleCalendarService {
  private oauth2Client: OAuth2Client

  constructor() {
    this.oauth2Client = new OAuth2Client(
      process.env.GOOGLE_CALENDAR_CLIENT_ID,
      process.env.GOOGLE_CALENDAR_CLIENT_SECRET,
      process.env.GOOGLE_CALENDAR_REDIRECT_URI
    )
  }

  async getAuthUrl(userId: string) {
    const scopes = [
      'https://www.googleapis.com/auth/calendar',
      'https://www.googleapis.com/auth/calendar.events',
    ]

    const url = this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      state: userId,
      prompt: 'consent',
    })

    return url
  }

  async handleCallback(code: string, userId: string) {
    try {
      const { tokens } = await this.oauth2Client.getToken(code)
      
      // Salvar tokens no banco
      await prisma.user.update({
        where: { id: userId },
        data: {
          googleTokens: tokens,
          googleCalendarConnected: true,
        },
      })

      return { success: true }
    } catch (error) {
      console.error('Google Calendar auth error:', error)
      throw error
    }
  }

  async createEvent(userId: string, appointment: any) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { googleTokens: true }
    })

    if (!user?.googleTokens) {
      throw new Error('Google Calendar não conectado')
    }

    this.oauth2Client.setCredentials(user.googleTokens)

    const calendar = google.calendar({ version: 'v3', auth: this.oauth2Client })

    const event = {
      summary: appointment.title,
      description: appointment.description || '',
      start: {
        dateTime: appointment.startTime,
        timeZone: 'America/Sao_Paulo',
      },
      end: {
        dateTime: appointment.endTime,
        timeZone: 'America/Sao_Paulo',
      },
      location: appointment.location || appointment.meetingLink || '',
      attendees: [
        { email: appointment.patient.email, displayName: appointment.patient.fullName },
      ],
      reminders: {
        useDefault: false,
        overrides: [
          { method: 'popup', minutes: 60 },
          { method: 'email', minutes: 24 * 60 },
        ],
      },
    }

    const response = await calendar.events.insert({
      calendarId: 'primary',
      requestBody: event,
      sendUpdates: 'all',
    })

    return response.data
  }

  async syncAppointments(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        organization: {
          include: {
            appointments: {
              where: {
                googleEventId: null,
                startTime: { gte: new Date() },
              },
              include: {
                patient: true,
              },
            },
          },
        },
      },
    })

    if (!user?.googleTokens) return { synced: 0 }

    const appointments = user.organization?.appointments || []
    let syncedCount = 0

    for (const appointment of appointments) {
      try {
        const googleEvent = await this.createEvent(userId, appointment)
        
        await prisma.appointment.update({
          where: { id: appointment.id },
          data: {
            googleEventId: googleEvent.id,
            googleCalendarId: googleEvent.calendarId || 'primary',
          },
        })

        syncedCount++
      } catch (error) {
        console.error(`Failed to sync appointment ${appointment.id}:`, error)
      }
    }

    return { synced: syncedCount }
  }
}

export const googleCalendarService = new GoogleCalendarService()