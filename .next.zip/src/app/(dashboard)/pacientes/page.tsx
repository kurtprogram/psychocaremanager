'use client'

import { useState, useEffect } from 'react'
import { Users, Search, Filter, UserPlus, Phone, Mail, Calendar, MoreVertical, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { useToast } from '@/hooks/useToast'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import PatientForm from '@/components/features/pacientes/PatientForm'

interface Patient {
  id: string
  fullName: string
  email: string | null
  phone: string
  whatsapp: string | null
  dateOfBirth: string | null
  gender: string | null
  status: string
  createdAt: string
  lastAppointment?: string
  nextAppointment?: string
  sessions?: number
}

export default function PacientesPage() {
  const { toast } = useToast()
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [patients, setPatients] = useState<Patient[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)

  useEffect(() => {
    fetchPatients()
  }, [])

  const fetchPatients = async () => {
    try {
      setIsLoading(true)
      const response = await fetch('/api/patients')
      if (!response.ok) throw new Error('Erro ao carregar pacientes')
      const data = await response.json()
      setPatients(data)
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar os pacientes',
        variant: 'destructive',
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddPatient = () => {
    setShowForm(true)
  }

  const handleFormSubmit = async (data: any) => {
    try {
      const response = await fetch('/api/patients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Erro ao criar paciente')
      }

      toast({
        title: 'Paciente criado!',
        description: `${data.fullName} foi adicionado com sucesso.`,
      })

      setShowForm(false)
      fetchPatients() // Recarregar lista
    } catch (error: any) {
      toast({
        title: 'Erro ao criar paciente',
        description: error.message,
        variant: 'destructive',
      })
    }
  }

  const filteredPatients = patients.filter(patient => {
    if (filter === 'active' && patient.status !== 'ACTIVE') return false
    if (filter === 'inactive' && patient.status !== 'INACTIVE') return false
    if (search && !patient.fullName.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Pacientes</h1>
          <p className="text-muted-foreground">
            Gerencie seus pacientes e histórico
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={handleAddPatient}>
            <UserPlus className="mr-2 h-4 w-4" />
            Novo Paciente
          </Button>
          <Button variant="outline" onClick={() => {}}>
            Exportar
          </Button>
        </div>
      </div>

      {/* Modal de Novo Paciente */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-900 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <PatientForm
              onSubmit={handleFormSubmit}
              onCancel={() => setShowForm(false)}
            />
          </div>
        </div>
      )}

      <div className="grid gap-6">
        {/* Estatísticas */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{patients.length}</div>
              <p className="text-xs text-muted-foreground">Pacientes cadastrados</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Ativos</CardTitle>
              <Badge className="bg-green-100 text-green-800">
                {patients.filter(p => p.status === 'ACTIVE').length}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {patients.filter(p => p.status === 'ACTIVE').length}
              </div>
              <p className="text-xs text-muted-foreground">
                {patients.length > 0 
                  ? `${Math.round((patients.filter(p => p.status === 'ACTIVE').length / patients.length) * 100)}% do total`
                  : '0%'
                }
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Novos/Mês</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {patients.filter(p => {
                  const monthAgo = new Date()
                  monthAgo.setMonth(monthAgo.getMonth() - 1)
                  return new Date(p.createdAt) > monthAgo
                }).length}
              </div>
              <p className="text-xs text-muted-foreground">Últimos 30 dias</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Cadastrados Hoje</CardTitle>
              <Badge className="bg-blue-100 text-blue-800">
                {patients.filter(p => {
                  const today = new Date()
                  const createdAt = new Date(p.createdAt)
                  return createdAt.toDateString() === today.toDateString()
                }).length}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {patients.filter(p => {
                  const today = new Date()
                  const createdAt = new Date(p.createdAt)
                  return createdAt.toDateString() === today.toDateString()
                }).length}
              </div>
              <p className="text-xs text-muted-foreground">Hoje</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabela de Pacientes */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Lista de Pacientes</CardTitle>
              <p className="text-sm text-muted-foreground">
                {filteredPatients.length} pacientes encontrados
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar paciente..."
                  className="pl-9 w-64"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <Button variant="outline" size="sm" onClick={() => setFilter(filter === 'all' ? 'active' : 'all')}>
                <Filter className="h-4 w-4 mr-2" />
                {filter === 'all' ? 'Ativos' : 'Todos'}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-moss-600" />
              </div>
            ) : (
              <>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Paciente</TableHead>
                        <TableHead>Contato</TableHead>
                        <TableHead>Data Nasc.</TableHead>
                        <TableHead>Cadastrado em</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPatients.map((patient) => (
                        <TableRow key={patient.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarFallback>{getInitials(patient.fullName)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{patient.fullName}</div>
                                <div className="text-sm text-muted-foreground">
                                  {patient.gender || 'Não informado'}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <Phone className="h-3 w-3" />
                                <span className="text-sm">{patient.phone}</span>
                              </div>
                              {patient.email && (
                                <div className="flex items-center gap-2">
                                  <Mail className="h-3 w-3" />
                                  <span className="text-sm">{patient.email}</span>
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            {patient.dateOfBirth ? (
                              <div className="text-sm">
                                {format(new Date(patient.dateOfBirth), 'dd/MM/yyyy')}
                              </div>
                            ) : (
                              <span className="text-sm text-muted-foreground">Não informado</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {format(new Date(patient.createdAt), 'dd/MM/yyyy')}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={
                              patient.status === 'ACTIVE' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-gray-100 text-gray-800'
                            }>
                              {patient.status === 'ACTIVE' ? 'Ativo' : 'Inativo'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>Ver perfil</DropdownMenuItem>
                                <DropdownMenuItem>Editar</DropdownMenuItem>
                                <DropdownMenuItem>Agendar consulta</DropdownMenuItem>
                                <DropdownMenuItem className="text-red-600">Inativar</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {filteredPatients.length === 0 && (
                  <div className="text-center py-12">
                    <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold">Nenhum paciente encontrado</h3>
                    <p className="text-muted-foreground mt-2">
                      {search ? 'Tente buscar com outros termos' : 'Adicione seu primeiro paciente'}
                    </p>
                    <Button className="mt-4" onClick={handleAddPatient}>
                      <UserPlus className="mr-2 h-4 w-4" />
                      Adicionar Paciente
                    </Button>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}