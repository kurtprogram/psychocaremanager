'use client'

import { useState, useEffect, useRef } from 'react'
import { Send, Paperclip, Smile, User, Clock, Check, CheckCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { useWebSocket } from '@/hooks/useWebSocket'
import { useToast } from '@/hooks/useToast'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

interface ChatWindowProps {
  otherUser: {
    id: string
    name: string
    image?: string
    isOnline?: boolean
  }
  appointmentId?: string
  className?: string
}

interface Message {
  id: string
  senderId: string
  receiverId: string
  message: string
  createdAt: string
  readAt?: string
  sender: {
    id: string
    name: string
    image?: string
  }
}

export default function ChatWindow({ otherUser, appointmentId, className }: ChatWindowProps) {
  const { toast } = useToast()
  const { sendMessage, isConnected, onlineUsers } = useWebSocket()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const isOtherUserOnline = onlineUsers.has(otherUser.id)

  useEffect(() => {
    fetchMessages()
  }, [otherUser.id, appointmentId])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const fetchMessages = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams({
        userId: otherUser.id,
        ...(appointmentId && { appointmentId }),
      })

      const response = await fetch(`/api/chat/messages?${params}`)
      if (!response.ok) throw new Error('Erro ao carregar mensagens')
      
      const data = await response.json()
      setMessages(data)
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar as mensagens',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!newMessage.trim() || !isConnected) return

    try {
      // Enviar via WebSocket para tempo real
      sendMessage(otherUser.id, newMessage.trim(), appointmentId)

      // Enviar para API para persistência
      const response = await fetch('/api/chat/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          receiverId: otherUser.id,
          message: newMessage.trim(),
          appointmentId,
        }),
      })

      if (!response.ok) throw new Error('Erro ao enviar mensagem')

      const result = await response.json()
      
      // Adicionar à lista localmente
      setMessages(prev => [...prev, result.message])
      setNewMessage('')

    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Não foi possível enviar a mensagem',
        variant: 'destructive',
      })
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage(e)
    }
  }

  if (loading) {
    return (
      <div className={`flex flex-col h-full ${className}`}>
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-moss-600"></div>
        </div>
      </div>
    )
  }

  return (
    <div className={`flex flex-col h-full ${className}`}>
      {/* Cabeçalho do Chat */}
      <div className="border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar>
            <AvatarImage src={otherUser.image} />
            <AvatarFallback>
              <User className="h-4 w-4" />
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-semibold">{otherUser.name}</h3>
            <div className="flex items-center gap-2">
              <div className={`h-2 w-2 rounded-full ${
                isOtherUserOnline ? 'bg-green-500' : 'bg-gray-300'
              }`} />
              <span className="text-xs text-muted-foreground">
                {isOtherUserOnline ? 'Online' : 'Offline'}
              </span>
            </div>
          </div>
        </div>
        <div className="text-xs text-muted-foreground">
          {isConnected ? '✅ Conectado' : '❌ Desconectado'}
        </div>
      </div>

      {/* Área de Mensagens */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-moss-100 flex items-center justify-center mb-4">
              <Send className="h-8 w-8 text-moss-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Nenhuma mensagem ainda</h3>
            <p className="text-muted-foreground">
              Envie sua primeira mensagem para {otherUser.name}
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isOwnMessage = msg.senderId === otherUser.id ? false : true
            const messageDate = new Date(msg.createdAt)
            
            return (
              <div
                key={msg.id}
                className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[70%] ${isOwnMessage ? 'order-2' : 'order-1'}`}>
                  <div
                    className={`rounded-2xl px-4 py-2 ${
                      isOwnMessage
                        ? 'bg-moss-600 text-white rounded-br-none'
                        : 'bg-gray-100 text-gray-900 rounded-bl-none'
                    }`}
                  >
                    <p className="text-sm">{msg.message}</p>
                  </div>
                  <div className={`flex items-center gap-2 mt-1 text-xs text-muted-foreground ${
                    isOwnMessage ? 'justify-end' : 'justify-start'
                  }`}>
                    <Clock className="h-3 w-3" />
                    <span>{format(messageDate, 'HH:mm')}</span>
                    {isOwnMessage && (
                      <>
                        {msg.readAt ? (
                          <CheckCheck className="h-3 w-3 text-blue-500" />
                        ) : (
                          <Check className="h-3 w-3 text-gray-400" />
                        )}
                      </>
                    )}
                  </div>
                </div>
                {!isOwnMessage && (
                  <div className="order-2 mr-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={msg.sender.image} />
                      <AvatarFallback>
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  </div>
                )}
              </div>
            )
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input de Mensagem */}
      <form onSubmit={handleSendMessage} className="border-t p-4">
        <div className="flex items-center gap-2">
          <Button type="button" variant="ghost" size="icon">
            <Paperclip className="h-4 w-4" />
          </Button>
          <div className="flex-1 relative">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Digite sua mensagem..."
              className="pr-10"
              disabled={!isConnected}
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 transform -translate-y-1/2"
            >
              <Smile className="h-4 w-4" />
            </Button>
          </div>
          <Button
            type="submit"
            size="icon"
            disabled={!newMessage.trim() || !isConnected}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2 text-center">
          Pressione Enter para enviar, Shift+Enter para nova linha
        </p>
      </form>
    </div>
  )
}