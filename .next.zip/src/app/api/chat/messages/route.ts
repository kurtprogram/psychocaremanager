import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { prisma } from '@/lib/prisma'
import { authConfig } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(req.url)
    const otherUserId = searchParams.get('userId')
    const appointmentId = searchParams.get('appointmentId')

    if (!otherUserId) {
      return NextResponse.json(
        { error: 'Usuário não especificado' },
        { status: 400 }
      )
    }

    const messages = await prisma.chatMessage.findMany({
      where: {
        OR: [
          {
            senderId: session.user.id,
            receiverId: otherUserId,
          },
          {
            senderId: otherUserId,
            receiverId: session.user.id,
          },
        ],
        ...(appointmentId && { appointmentId }),
      },
      orderBy: {
        createdAt: 'asc',
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            image: true,
          },
        },
      },
      take: 50, // Últimas 50 mensagens
    })

    return NextResponse.json(messages)
  } catch (error) {
    console.error('Error fetching messages:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar mensagens' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const body = await req.json()
    const { receiverId, message, appointmentId } = body

    if (!receiverId || !message?.trim()) {
      return NextResponse.json(
        { error: 'Dados inválidos' },
        { status: 400 }
      )
    }

    const chatMessage = await prisma.chatMessage.create({
      data: {
        senderId: session.user.id,
        receiverId,
        message: message.trim(),
        appointmentId,
        organizationId: session.user.organizationId!,
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            image: true,
          },
        },
      },
    })

    // Log de auditoria
    await prisma.auditLog.create({
      data: {
        organizationId: session.user.organizationId!,
        userId: session.user.id,
        userEmail: session.user.email!,
        userName: session.user.name!,
        action: 'CHAT_MESSAGE',
        entityType: 'CHAT',
        entityId: chatMessage.id,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    return NextResponse.json({
      success: true,
      message: chatMessage,
    })
  } catch (error) {
    console.error('Error sending message:', error)
    return NextResponse.json(
      { error: 'Erro ao enviar mensagem' },
      { status: 500 }
    )
  }
}