'use client'

import { useState } from 'react'
import { FileText, Search, Filter, Plus, Lock, Download, Eye, Edit, User, Calendar, Stethoscope } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { useToast } from '@/hooks/useToast'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

const medicalRecords = [
  {
    id: 1,
    patient: 'João Silva',
    professional: 'Dra. Maria Silva',
    date: '2024-01-10',
    sessionNumber: 5,
    diagnosis: 'Ansiedade Generalizada',
    treatmentPlan: 'TCC - 12 sessões',
    encrypted: true,
  },
  {
    id: 2,
    patient: 'Maria Santos',
    professional: 'Dra. Maria Silva',
    date: '2024-01-12',
    sessionNumber: 8,
    diagnosis: 'Depressão Moderada',
    treatmentPlan: 'Psicoterapia Integrativa',
    encrypted: true,
  },
  {
    id: 3,
    patient: 'Pedro Oliveira',
    professional: 'Dr. Carlos Mendes',
    date: '2024-01-05',
    sessionNumber: 3,
    diagnosis: 'Estresse Pós-Traumático',
    treatmentPlan: 'EMDR + TCC',
    encrypted: false,
  },
]

export default function ProntuariosPage() {
  const { toast } = useToast()
  const [search, setSearch] = useState('')
  const [activeTab, setActiveTab] = useState('all')

  const handleNewRecord = () => {
    toast({
      title: 'Novo prontuário',
      description: 'Abrindo editor...',
    })
  }

  const handleExportPDF = (recordId: number) => {
    toast({
      title: 'Exportando prontuário',
      description: 'Gerando PDF...',
    })
  }

  const handleEncrypt = (recordId: number) => {
    toast({
      title: 'Criptografando',
      description: 'Prontuário protegido com criptografia de ponta a ponta',
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Prontuários</h1>
          <p className="text-muted-foreground">
            Prontuários eletrônicos seguros e organizados
          </p>
        </div>
        <Button onClick={handleNewRecord}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Prontuário
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full md:w-auto grid-cols-3 md:inline-flex">
          <TabsTrigger value="all">Todos</TabsTrigger>
          <TabsTrigger value="encrypted">Criptografados</TabsTrigger>
          <TabsTrigger value="recent">Recentes</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6 mt-6">
          {/* Filtros e Busca */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por paciente, diagnóstico..."
                    className="pl-9"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtros
                  </Button>
                  <Button variant="outline">
                    Ordenar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Lista de Prontuários */}
          <Card>
            <CardHeader>
              <CardTitle>Prontuários Eletrônicos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Paciente</TableHead>
                      <TableHead>Profissional</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Sessão</TableHead>
                      <TableHead>Diagnóstico</TableHead>
                      <TableHead>Plano</TableHead>
                      <TableHead>Segurança</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {medicalRecords.map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{record.patient}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Stethoscope className="h-4 w-4 text-muted-foreground" />
                            <span>{record.professional}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>{format(new Date(record.date), 'dd/MM/yyyy')}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">Sessão {record.sessionNumber}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="max-w-xs truncate">{record.diagnosis}</div>
                        </TableCell>
                        <TableCell>
                          <div className="max-w-xs truncate">{record.treatmentPlan}</div>
                        </TableCell>
                        <TableCell>
                          {record.encrypted ? (
                            <Badge className="bg-green-100 text-green-800">
                              <Lock className="h-3 w-3 mr-1" />
                              Criptografado
                            </Badge>
                          ) : (
                            <Badge variant="outline">Padrão</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button size="sm" variant="ghost">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button size="sm" variant="ghost">
                                  ⋮
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleExportPDF(record.id)}>
                                  <Download className="h-4 w-4 mr-2" />
                                  Exportar PDF
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleEncrypt(record.id)}>
                                  <Lock className="h-4 w-4 mr-2" />
                                  {record.encrypted ? 'Descriptografar' : 'Criptografar'}
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-red-600">
                                  Excluir
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Estatísticas de Segurança */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Prontuários Criptografados</CardTitle>
                <Lock className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">85%</div>
                <p className="text-xs text-muted-foreground">Conformidade LGPD</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Acessos Hoje</CardTitle>
                <Eye className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24</div>
                <p className="text-xs text-muted-foreground">+8% vs ontem</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Backup Automático</CardTitle>
                <Badge className="bg-green-100 text-green-800">Ativo</Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Último: 02:00</div>
                <p className="text-xs text-muted-foreground">Próximo: 02:00</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Editor Simples */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Editor de Prontuário
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium">Paciente</label>
                <Input placeholder="Selecione o paciente" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Data da Sessão</label>
                <Input type="date" />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Subjetivo (Queixa do paciente)</label>
              <textarea 
                className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm"
                placeholder="Descreva a queixa principal do paciente..."
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Objetivo (Observações)</label>
              <textarea 
                className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm"
                placeholder="Observações comportamentais, emocionais..."
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Avaliação (Diagnóstico/Progresso)</label>
              <textarea 
                className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm"
                placeholder="Avaliação clínica, diagnóstico, progresso..."
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Plano (Próximos passos)</label>
              <textarea 
                className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm"
                placeholder="Plano de tratamento, tarefas, próximas sessões..."
              />
            </div>
            
            <div className="flex justify-between pt-4">
              <Button variant="outline">Salvar Rascunho</Button>
              <Button>
                <Lock className="mr-2 h-4 w-4" />
                Salvar e Criptografar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}