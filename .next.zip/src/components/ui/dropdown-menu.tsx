import * as React from 'react'

export function DropdownMenu({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props}>{children}</div>
}

export function DropdownMenuTrigger({ children, asChild, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { asChild?: boolean }) {
  return <button {...props}>{children}</button>
}

export function DropdownMenuContent({ children, align, ...props }: React.HTMLAttributes<HTMLDivElement> & { align?: string }) {
  return <div {...props} data-align={align}>{children}</div>
}

export function DropdownMenuItem({ children, asChild, ...props }: React.HTMLAttributes<HTMLDivElement> & { asChild?: boolean }) {
  return <div {...props}>{children}</div>
}

export function DropdownMenuLabel({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props}>{children}</div>
}

export function DropdownMenuSeparator({ ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} />
}
