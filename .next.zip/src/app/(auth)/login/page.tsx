'use client'

import { useState } from 'react'
import { Settings, Bell, MessageSquare, Mail, Shield, Globe, User, Smartphone, Save } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/hooks/useToast'

export default function ConfiguracoesPage() {
  const { toast } = useToast()
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      whatsapp: true,
      push: false,
      reminders: true,
      confirmations: true,
    },
    whatsapp: {
      enabled: true,
      businessPhone: '(11) 99999-9999',
      templates: {
        appointmentConfirmation: true,
        appointmentReminder: true,
        welcomeMessage: true,
      }
    },
    profile: {
      name: 'Dra. Maria Silva',
      email: 'maria@psicologia.com',
      phone: '(11) 99999-9999',
      whatsapp: '(11) 99999-9999',
      specialty: 'Psicologia Clínica',
      bio: 'Especialista em terapia cognitivo-comportamental com 10 anos de experiência.',
    },
    system: {
      language: 'pt',
      timezone: 'America/Sao_Paulo',
      theme: 'system',
    }
  })

  const handleSave = () => {
    toast({
      title: 'Configurações salvas',
      description: 'Suas configurações foram atualizadas com sucesso.',
    })
  }

  const handleChange = (category: string, field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [field]: value
      }
    }))
  }

  const handleNestedChange = (category: string, subcategory: string, field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [subcategory]: {
          ...(prev[category as keyof typeof prev] as any)[subcategory],
          [field]: value
        }
      }
    }))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
          <p className="text-muted-foreground">
            Personalize sua experiência no sistema
          </p>
        </div>
        <Button onClick={handleSave}>
          <Save className="mr-2 h-4 w-4" />
          Salvar Alterações
        </Button>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden md:inline">Perfil</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden md:inline">Notificações</span>
          </TabsTrigger>
          <TabsTrigger value="whatsapp" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            <span className="hidden md:inline">WhatsApp</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden md:inline">Segurança</span>
          </TabsTrigger>
          <TabsTrigger value="system" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            <span className="hidden md:inline">Sistema</span>
          </TabsTrigger>
        </TabsList>

        {/* Perfil */}
        <TabsContent value="profile" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações Pessoais</CardTitle>
              <CardDescription>
                Atualize suas informações de perfil
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome Completo</Label>
                  <Input
                    id="name"
                    value={settings.profile.name}
                    onChange={(e) => handleChange('profile', 'name', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input
                    id="email"
                    type="email"
                    value={settings.profile.email}
                    onChange={(e) => handleChange('profile', 'email', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone</Label>
                  <Input
                    id="phone"
                    value={settings.profile.phone}
                    onChange={(e) => handleChange('profile', 'phone', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="whatsapp">WhatsApp</Label>
                  <Input
                    id="whatsapp"
                    value={settings.profile.whatsapp}
                    onChange={(e) => handleChange('profile', 'whatsapp', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="specialty">Especialidade</Label>
                  <Input
                    id="specialty"
                    value={settings.profile.specialty}
                    onChange={(e) => handleChange('profile', 'specialty', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Idioma Principal</Label>
                  <Select
                    value={settings.system.language}
                    onValueChange={(value) => handleChange('system', 'language', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pt">Português</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bio">Biografia</Label>
                <Textarea
                  id="bio"
                  value={settings.profile.bio}
                  onChange={(e) => handleChange('profile', 'bio', e.target.value)}
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notificações */}
        <TabsContent value="notifications" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Preferências de Notificação</CardTitle>
              <CardDescription>
                Escolha como você deseja receber notificações
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Notificações por E-mail</Label>
                    <p className="text-sm text-muted-foreground">
                      Receba notificações no seu e-mail
                    </p>
                  </div>
                  <Switch
                    checked={settings.notifications.email}
                    onCheckedChange={(checked: boolean) => handleChange('notifications', 'email', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Notificações por WhatsApp</Label>
                    <p className="text-sm text-muted-foreground">
                      Receba notificações no WhatsApp
                    </p>
                  </div>
                  <Switch
                    checked={settings.notifications.whatsapp}
                    onCheckedChange={(checked: boolean) => handleChange('notifications', 'whatsapp', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Notificações Push</Label>
                    <p className="text-sm text-muted-foreground">
                      Receba notificações no navegador
                    </p>
                  </div>
                  <Switch
                    checked={settings.notifications.push}
                    onCheckedChange={(checked: boolean) => handleChange('notifications', 'push', checked)}
                  />
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Tipos de Notificação</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Lembretes de Consulta</Label>
                      <p className="text-sm text-muted-foreground">
                        Lembrete 1 hora antes da consulta
                      </p>
                    </div>
                    <Switch
                      checked={settings.notifications.reminders}
                      onCheckedChange={(checked: boolean) => handleChange('notifications', 'reminders', checked)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Confirmações de Consulta</Label>
                      <p className="text-sm text-muted-foreground">
                        Confirmação após agendamento
                      </p>
                    </div>
                    <Switch
                      checked={settings.notifications.confirmations}
                      onCheckedChange={(checked: boolean) => handleChange('notifications', 'confirmations', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* WhatsApp */}
        <TabsContent value="whatsapp" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Configurações do WhatsApp
              </CardTitle>
              <CardDescription>
                Configure a integração com WhatsApp Business
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Integração WhatsApp</Label>
                  <p className="text-sm text-muted-foreground">
                    Ativar envio automático de mensagens
                  </p>
                </div>
                <Switch
                  checked={settings.whatsapp.enabled}
                  onCheckedChange={(checked: boolean) => handleChange('whatsapp', 'enabled', checked)}
                />
              </div>

              {settings.whatsapp.enabled && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="businessPhone">Número WhatsApp Business</Label>
                    <Input
                      id="businessPhone"
                      value={settings.whatsapp.businessPhone}
                      onChange={(e) => handleChange('whatsapp', 'businessPhone', e.target.value)}
                      placeholder="(11) 99999-9999"
                    />
                  </div>

                  <div className="border-t pt-6">
                    <h3 className="text-lg font-semibold mb-4">Templates de Mensagem</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Confirmação de Consulta</Label>
                          <p className="text-sm text-muted-foreground">
                            Enviar quando consulta for confirmada
                          </p>
                        </div>
                        <Switch
                          checked={settings.whatsapp.templates.appointmentConfirmation}
                          onCheckedChange={(checked: boolean) => 
                            handleNestedChange('whatsapp', 'templates', 'appointmentConfirmation', checked)
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Lembrete de Consulta</Label>
                          <p className="text-sm text-muted-foreground">
                            Enviar 1 hora antes da consulta
                          </p>
                        </div>
                        <Switch
                          checked={settings.whatsapp.templates.appointmentReminder}
                          onCheckedChange={(checked: boolean) => 
                            handleNestedChange('whatsapp', 'templates', 'appointmentReminder', checked)
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Mensagem de Boas-vindas</Label>
                          <p className="text-sm text-muted-foreground">
                            Enviar para novos pacientes
                          </p>
                        </div>
                        <Switch
                          checked={settings.whatsapp.templates.welcomeMessage}
                          onCheckedChange={(checked: boolean) => 
                            handleNestedChange('whatsapp', 'templates', 'welcomeMessage', checked)
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-6">
                    <h3 className="text-lg font-semibold mb-4">Pré-visualização</h3>
                    <div className="rounded-lg border bg-gray-50 p-4 max-w-md">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                          <MessageSquare className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">WhatsApp Business</p>
                          <p className="text-xs text-muted-foreground">Agora mesmo</p>
                        </div>
                      </div>
                      <div className="bg-white rounded-lg p-3 shadow-sm">
                        <p className="text-sm">
                          Olá [Nome do Paciente]! Sua consulta com Dra. Maria Silva foi confirmada para 
                          amanhã às 14:00. Clique aqui para adicionar ao calendário.
                        </p>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Segurança */}
        <TabsContent value="security" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Segurança e Privacidade
              </CardTitle>
              <CardDescription>
                Configure as opções de segurança da sua conta
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="currentPassword">Senha Atual</Label>
                  <Input id="currentPassword" type="password" />
                </div>
                
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">Nova Senha</Label>
                    <Input id="newPassword" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                    <Input id="confirmPassword" type="password" />
                  </div>
                </div>
                
                <Button>Alterar Senha</Button>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Sessões Ativas</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Chrome • Windows</p>
                      <p className="text-sm text-muted-foreground">São Paulo, Brasil • Ativo agora</p>
                    </div>
                    <Button variant="outline" size="sm">Terminar</Button>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Safari • iPhone</p>
                      <p className="text-sm text-muted-foreground">Ontem às 14:30</p>
                    </div>
                    <Button variant="outline" size="sm">Terminar</Button>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Conformidade LGPD</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Criptografia de Ponta a Ponta</Label>
                      <p className="text-sm text-muted-foreground">
                        Prontuários criptografados automaticamente
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Backup Automático</Label>
                      <p className="text-sm text-muted-foreground">
                        Backup diário dos dados
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Registro de Auditoria</Label>
                      <p className="text-sm text-muted-foreground">
                        Log de todas as ações no sistema
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sistema */}
        <TabsContent value="system" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Configurações do Sistema
              </CardTitle>
              <CardDescription>
                Preferências gerais do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="timezone">Fuso Horário</Label>
                  <Select
                    value={settings.system.timezone}
                    onValueChange={(value) => handleChange('system', 'timezone', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="America/Sao_Paulo">Brasília (GMT-3)</SelectItem>
                      <SelectItem value="America/New_York">Nova York (GMT-5)</SelectItem>
                      <SelectItem value="Europe/London">Londres (GMT+0)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="theme">Tema</Label>
                  <Select
                    value={settings.system.theme}
                    onValueChange={(value) => handleChange('system', 'theme', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Claro</SelectItem>
                      <SelectItem value="dark">Escuro</SelectItem>
                      <SelectItem value="system">Sistema</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Exportação de Dados</h3>
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Exporte todos os seus dados em formato compatível com a LGPD
                  </p>
                  <div className="flex gap-3">
                    <Button variant="outline">Exportar Meus Dados</Button>
                    <Button variant="outline">Exportar Dados dos Pacientes</Button>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Sobre o Sistema</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Versão</span>
                    <span className="text-sm font-medium">1.0.0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Última Atualização</span>
                    <span className="text-sm font-medium">15/01/2024</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Licença</span>
                    <span className="text-sm font-medium">Commercial</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}