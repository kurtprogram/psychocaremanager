import { Server } from 'socket.io'
import { createServer } from 'http'
import { parse } from 'url'
import next from 'next'
import type { Server as HTTPServer } from 'http'
import type { Socket as NetSocket } from 'net'

const dev = process.env.NODE_ENV !== 'production'
const app = next({ dev })
const handler = app.getRequestHandler()

app.prepare().then(() => {
  const httpServer = createServer((req, res) => {
    const parsedUrl = parse(req.url!, true)
    handler(req, res, parsedUrl)
  })

  const io = new Server(httpServer, {
    cors: {
      origin: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
      methods: ['GET', 'POST'],
    },
  })

  // Map para armazenar userID -> socketID
  const userSocketMap = new Map<string, string>()
  const organizationSocketMap = new Map<string, Set<string>>()

  io.on('connection', (socket: any) => {
    console.log('Novo cliente conectado:', socket.id)

    // Cliente se identifica
    socket.on('identify', (userId: string) => {
      userSocketMap.set(userId, socket.id)
      console.log(`Usuário ${userId} conectado como socket ${socket.id}`)
    })

    // Entrar em sala de organização
    socket.on('join-organization', (organizationId: string) => {
      socket.join(`org:${organizationId}`)
      
      if (!organizationSocketMap.has(organizationId)) {
        organizationSocketMap.set(organizationId, new Set())
      }
      organizationSocketMap.get(organizationId)!.add(socket.id)
      
      console.log(`Socket ${socket.id} entrou na organização ${organizationId}`)
    })

    // Sair de sala de organização
    socket.on('leave-organization', (organizationId: string) => {
      socket.leave(`org:${organizationId}`)
      organizationSocketMap.get(organizationId)?.delete(socket.id)
    })

    // Notificação de nova consulta
    socket.on('new-appointment', (data: { 
      appointmentId: string
      patientId: string
      professionalId: string
      organizationId: string
    }) => {
      // Notificar profissional
      const professionalSocketId = userSocketMap.get(data.professionalId)
      if (professionalSocketId) {
        io.to(professionalSocketId).emit('appointment-created', {
          type: 'NEW_APPOINTMENT',
          message: 'Nova consulta agendada',
          appointmentId: data.appointmentId,
          timestamp: new Date().toISOString(),
        })
      }

      // Notificar toda a organização
      io.to(`org:${data.organizationId}`).emit('organization-notification', {
        type: 'APPOINTMENT_CREATED',
        message: 'Nova consulta agendada na organização',
        appointmentId: data.appointmentId,
        timestamp: new Date().toISOString(),
      })
    })

    // Notificação de lembrete
    socket.on('appointment-reminder', (data: {
      appointmentId: string
      patientId: string
      professionalId: string
      minutesBefore: number
    }) => {
      const patientSocketId = userSocketMap.get(data.patientId)
      const professionalSocketId = userSocketMap.get(data.professionalId)

      if (patientSocketId) {
        io.to(patientSocketId).emit('reminder', {
          type: 'APPOINTMENT_REMINDER',
          message: `Sua consulta começa em ${data.minutesBefore} minutos`,
          appointmentId: data.appointmentId,
          timestamp: new Date().toISOString(),
        })
      }

      if (professionalSocketId) {
        io.to(professionalSocketId).emit('reminder', {
          type: 'APPOINTMENT_REMINDER',
          message: `Próxima consulta em ${data.minutesBefore} minutos`,
          appointmentId: data.appointmentId,
          timestamp: new Date().toISOString(),
        })
      }
    })

    // Mensagem em tempo real (chat entre profissional e paciente)
    socket.on('send-message', (data: {
      senderId: string
      receiverId: string
      message: string
      appointmentId?: string
    }) => {
      const receiverSocketId = userSocketMap.get(data.receiverId)
      
      if (receiverSocketId) {
        io.to(receiverSocketId).emit('new-message', {
          senderId: data.senderId,
          message: data.message,
          timestamp: new Date().toISOString(),
          appointmentId: data.appointmentId,
        })
      }
    })

    // Status online/offline
    socket.on('presence', (data: { userId: string, status: 'online' | 'away' | 'offline' }) => {
      // Notificar colegas da mesma organização
      socket.broadcast.emit('presence-update', {
        userId: data.userId,
        status: data.status,
        timestamp: new Date().toISOString(),
      })
    })

    // Desconexão
    socket.on('disconnect', () => {
      console.log('Cliente desconectado:', socket.id)
      
      // Remover do mapa de usuários
      userSocketMap.forEach((socketId, userId) => {
        if (socketId === socket.id) {
          userSocketMap.delete(userId)

          // Notificar que usuário está offline
          socket.broadcast.emit('presence-update', {
            userId,
            status: 'offline',
            timestamp: new Date().toISOString(),
          })
        }
      })

      // Remover do mapa de organizações
      organizationSocketMap.forEach((socketSet, orgId) => {
        if (socketSet.has(socket.id)) {
          socketSet.delete(socket.id)
          if (socketSet.size === 0) {
            organizationSocketMap.delete(orgId)
          }
        }
      })
    })
  })

  const PORT = process.env.PORT || 3001
  httpServer.listen(PORT, () => {
    console.log(`🚀 Socket.IO server running on port ${PORT}`)
    console.log(`🌐 WebSocket URL: ws://localhost:${PORT}`)
  })
})