import Stripe from 'stripe'
import { prisma } from '@/lib/prisma'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
})

class StripeService {
  async createCustomer(user: any) {
    const customer = await stripe.customers.create({
      email: user.email,
      name: user.name,
      phone: user.phone,
      metadata: {
        userId: user.id,
        organizationId: user.organizationId,
      },
    })

    await prisma.user.update({
      where: { id: user.id },
      data: { stripeCustomerId: customer.id },
    })

    return customer
  }

  async createSubscription(customerId: string, priceId: string) {
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      payment_behavior: 'default_incomplete',
      expand: ['latest_invoice.payment_intent'],
      metadata: {
        setup_future_usage: 'off_session',
      },
    })

    return subscription
  }

  async createCheckoutSession(
    customerId: string,
    priceId: string,
    successUrl: string,
    cancelUrl: string
  ) {
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card', 'pix'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: successUrl,
      cancel_url: cancelUrl,
      allow_promotion_codes: true,
      subscription_data: {
        trial_period_days: 7,
        metadata: {
          trial: 'true',
        },
      },
    })

    return session
  }

  async createPixPayment(amount: number, description: string) {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // Convert to cents
      currency: 'brl',
      payment_method_types: ['pix'],
      description,
    })

    return paymentIntent
  }

  async handleWebhook(event: Stripe.Event) {
    switch (event.type) {
      case 'checkout.session.completed':
        await this.handleCheckoutCompleted(event.data.object as Stripe.Checkout.Session)
        break
      
      case 'invoice.payment_succeeded':
        await this.handlePaymentSucceeded(event.data.object as Stripe.Invoice)
        break
      
      case 'customer.subscription.updated':
        await this.handleSubscriptionUpdated(event.data.object as Stripe.Subscription)
        break
      
      case 'customer.subscription.deleted':
        await this.handleSubscriptionDeleted(event.data.object as Stripe.Subscription)
        break
    }
  }

  private async handleSubscriptionUpdated(subscription: Stripe.Subscription) {
    const org = await prisma.organization.findFirst({ where: { stripeSubscriptionId: subscription.id } })

    if (!org) {
      // Try find by customer and attach
      const customerId = (subscription.customer as string) || null
      if (customerId) {
        await prisma.organization.updateMany({ where: { stripeCustomerId: customerId }, data: { stripeSubscriptionId: subscription.id } })
      }
    } else {
      await prisma.organization.update({
        where: { id: org.id },
        data: {
          status: subscription.status === 'active' || subscription.status === 'trialing' ? 'ACTIVE' : 'PAUSED',
          subscriptionEnd: subscription.current_period_end ? new Date(subscription.current_period_end * 1000) : org.subscriptionEnd,
        },
      })
    }
  }

  private async handleSubscriptionDeleted(subscription: Stripe.Subscription) {
    const org = await prisma.organization.findFirst({ where: { stripeSubscriptionId: subscription.id } })
    if (org) {
      await prisma.organization.update({
        where: { id: org.id },
        data: {
          status: 'CANCELED',
          subscriptionEnd: subscription.ended_at ? new Date(subscription.ended_at * 1000) : new Date(),
        },
      })
    }
  }

  private async handleCheckoutCompleted(session: Stripe.Checkout.Session) {
    const customerId = session.customer as string
    const subscriptionId = session.subscription as string

    await prisma.organization.update({
      where: { stripeCustomerId: customerId },
      data: {
        stripeSubscriptionId: subscriptionId,
        status: 'ACTIVE',
        subscriptionStart: new Date(),
        subscriptionEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
        trialEndsAt: null,
      },
    })
  }

  private async handlePaymentSucceeded(invoice: Stripe.Invoice) {
    const customerId = invoice.customer as string
    
    await prisma.payment.create({
      data: {
        organizationId: await this.getOrganizationId(customerId),
        amount: invoice.amount_paid / 100,
        currency: invoice.currency,
        method: 'CREDIT_CARD',
        status: 'PAID',
        dueDate: new Date(invoice.due_date || invoice.created * 1000),
        paidAt: new Date(),
        stripePaymentId: invoice.payment_intent as string,
        stripeInvoiceId: invoice.id,
        description: `Fatura Stripe ${invoice.number}`,
      },
    })
  }

  private async getOrganizationId(customerId: string): Promise<string> {
    const org = await prisma.organization.findFirst({
      where: { stripeCustomerId: customerId },
    })
    
    if (!org) throw new Error('Organization not found')
    return org.id
  }
}

export const stripeService = new StripeService()