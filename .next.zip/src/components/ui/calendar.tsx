import * as React from 'react'

export function Calendar({ onDateSelect, ...props }: { onDateSelect?: (date?: Date) => void } & React.HTMLAttributes<HTMLDivElement> & Record<string, any>) {
  // This placeholder triggers onDateSelect when clicked for demo purposes
  return <div {...props} onClick={() => onDateSelect?.(new Date())} />
}
