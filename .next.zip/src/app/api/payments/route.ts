import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import { authConfig } from '@/lib/auth'

const paymentSchema = z.object({
  patientId: z.string(),
  appointmentId: z.string().optional(),
  amount: z.number().positive('Valor deve ser positivo'),
  currency: z.string().default('BRL'),
  method: z.enum(['PIX', 'INSURANCE', 'CASH', 'CREDIT_CARD', 'BANK_TRANSFER']),
  dueDate: z.string().datetime(),
  reference: z.string().optional(),
  description: z.string().optional(),
  notes: z.string().optional(),
})

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(req.url)
    const status = searchParams.get('status')
    const startDate = searchParams.get('start')
    const endDate = searchParams.get('end')

    const payments = await prisma.payment.findMany({
      where: {
        organizationId: session.user.organizationId,
        deletedAt: null,
        ...(status && { status }),
        ...(startDate && endDate && {
          dueDate: {
            gte: new Date(startDate),
            lte: new Date(endDate),
          },
        }),
      },
      include: {
        patient: {
          select: {
            id: true,
            fullName: true,
            phone: true,
          },
        },
        appointment: {
          select: {
            id: true,
            title: true,
            startTime: true,
          },
        },
      },
      orderBy: {
        dueDate: 'desc',
      },
    })

    return NextResponse.json(payments)
  } catch (error) {
    console.error('Error fetching payments:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar pagamentos' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const body = await req.json()
    const validated = paymentSchema.parse(body)

    // Criar pagamento
    const payment = await prisma.payment.create({
      data: {
        organizationId: session.user.organizationId,
        patientId: validated.patientId,
        appointmentId: validated.appointmentId,
        amount: validated.amount,
        currency: validated.currency,
        method: validated.method,
        dueDate: new Date(validated.dueDate),
        reference: validated.reference,
        description: validated.description,
        notes: validated.notes,
        status: 'PENDING',
      },
      include: {
        patient: true,
        appointment: true,
      },
    })

    // Log de auditoria
    await prisma.auditLog.create({
      data: {
        organizationId: session.user.organizationId,
        userId: session.user.id,
        userEmail: session.user.email!,
        userName: session.user.name!,
        action: 'CREATE',
        entityType: 'PAYMENT',
        entityId: payment.id,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    // Notificar paciente se for PIX
    if (validated.method === 'PIX') {
      await prisma.notification.create({
        data: {
          organizationId: session.user.organizationId,
          patientId: payment.patientId,
          type: 'PAYMENT_REQUEST',
          channel: 'WHATSAPP',
          title: 'Pagamento Pendente',
          message: `Você tem um pagamento de R$ ${validated.amount.toFixed(2)} pendente. Vencimento: ${new Date(validated.dueDate).toLocaleDateString('pt-BR')}`,
          status: 'PENDING',
        },
      })
    }

    return NextResponse.json({
      success: true,
      payment,
    })

  } catch (error: any) {
    console.error('Error creating payment:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Erro ao criar pagamento' },
      { status: 500 }
    )
  }
}