'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { io, Socket } from 'socket.io-client'
import { useSession } from 'next-auth/react'

export const useWebSocket = () => {
  const { data: session } = useSession()
  const socketRef = useRef<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [notifications, setNotifications] = useState<any[]>([])
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set())

  const connect = useCallback(() => {
    if (socketRef.current?.connected) return

    const socket = io(process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:3001', {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    })

    socketRef.current = socket

    socket.on('connect', () => {
      console.log('✅ WebSocket conectado')
      setIsConnected(true)

      // Identificar usuário
      if (session?.user?.id) {
        socket.emit('identify', session.user.id)
      }

      // Entrar na organização
      if (session?.user?.organizationId) {
        socket.emit('join-organization', session.user.organizationId)
      }
    })

    socket.on('disconnect', () => {
      console.log('❌ WebSocket desconectado')
      setIsConnected(false)
    })

    socket.on('appointment-created', (data) => {
      console.log('Nova consulta:', data)
      setNotifications(prev => [data, ...prev.slice(0, 9)]) // Mantém apenas 10 notificações
    })

    socket.on('reminder', (data) => {
      console.log('Lembrete:', data)
      setNotifications(prev => [data, ...prev.slice(0, 9)])
    })

    socket.on('new-message', (data) => {
      console.log('Nova mensagem:', data)
      setNotifications(prev => [data, ...prev.slice(0, 9)])
    })

    socket.on('organization-notification', (data) => {
      console.log('Notificação da organização:', data)
      setNotifications(prev => [data, ...prev.slice(0, 9)])
    })

    socket.on('presence-update', (data) => {
      console.log('Atualização de presença:', data)
      setOnlineUsers(prev => {
        const newSet = new Set(prev)
        if (data.status === 'online') {
          newSet.add(data.userId)
        } else {
          newSet.delete(data.userId)
        }
        return newSet
      })
    })

    socket.on('error', (error) => {
      console.error('Erro no WebSocket:', error)
    })

    return socket
  }, [session])

  const disconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.disconnect()
      socketRef.current = null
      setIsConnected(false)
    }
  }, [])

  const sendMessage = useCallback((receiverId: string, message: string, appointmentId?: string) => {
    if (socketRef.current?.connected && session?.user?.id) {
      socketRef.current.emit('send-message', {
        senderId: session.user.id,
        receiverId,
        message,
        appointmentId,
      })
    }
  }, [session])

  const updatePresence = useCallback((status: 'online' | 'away' | 'offline') => {
    if (socketRef.current?.connected && session?.user?.id) {
      socketRef.current.emit('presence', {
        userId: session.user.id,
        status,
      })
    }
  }, [session])

  const clearNotifications = useCallback(() => {
    setNotifications([])
  }, [])

  // Conectar/desconectar quando o componente monta/desmonta
  useEffect(() => {
    const socket = connect()

    return () => {
      if (socket) {
        socket.disconnect()
      }
    }
  }, [connect])

  // Reconnect quando a sessão muda
  useEffect(() => {
    if (session?.user?.id && socketRef.current) {
      socketRef.current.emit('identify', session.user.id)
      if (session.user.organizationId) {
        socketRef.current.emit('join-organization', session.user.organizationId)
      }
    }
  }, [session])

  return {
    socket: socketRef.current,
    isConnected,
    notifications,
    onlineUsers,
    sendMessage,
    updatePresence,
    clearNotifications,
    reconnect: connect,
    disconnect,
  }
}