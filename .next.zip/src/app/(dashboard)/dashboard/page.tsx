'use client'

import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useToast } from '@/hooks/useToast'
import { Calendar, Users, DollarSign, FileText, Bell, TrendingUp, Clock, CheckCircle } from 'lucide-react'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

export default function DashboardPage() {
  const { data: session } = useSession()
  const { toast } = useToast()
  
  const user = session?.user as any
  const stats = [
    {
      title: 'Consultas Hoje',
      value: '3',
      icon: <Calendar className="h-5 w-5" />,
      change: '+2',
      description: 'em relação a ontem',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
    },
    {
      title: 'Pacientes Ativos',
      value: '42',
      icon: <Users className="h-5 w-5" />,
      change: '+5',
      description: 'este mês',
      color: 'text-green-600',
      bgColor: 'bg-green-100',
    },
    {
      title: 'Receita Mensal',
      value: 'R$ 8.240',
      icon: <DollarSign className="h-5 w-5" />,
      change: '+12%',
      description: 'em relação ao mês passado',
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-100',
    },
    {
      title: 'Prontuários',
      value: '156',
      icon: <FileText className="h-5 w-5" />,
      change: '+8',
      description: 'este mês',
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
    },
  ]

  const upcomingAppointments = [
    {
      id: 1,
      patient: 'João Silva',
      time: '09:00',
      type: 'Presencial',
      status: 'Confirmado',
    },
    {
      id: 2,
      patient: 'Maria Santos',
      time: '10:30',
      type: 'Online',
      status: 'Confirmado',
    },
    {
      id: 3,
      patient: 'Pedro Oliveira',
      time: '14:00',
      type: 'Presencial',
      status: 'Pendente',
    },
  ]

  const recentActivity = [
    {
      id: 1,
      action: 'Consulta realizada',
      patient: 'Ana Costa',
      time: 'há 2 horas',
      icon: <CheckCircle className="h-4 w-4 text-green-500" />,
    },
    {
      id: 2,
      action: 'Novo paciente',
      patient: 'Carlos Mendes',
      time: 'há 4 horas',
      icon: <Users className="h-4 w-4 text-blue-500" />,
    },
    {
      id: 3,
      action: 'Pagamento recebido',
      patient: 'Fernanda Lima',
      time: 'há 1 dia',
      icon: <DollarSign className="h-4 w-4 text-emerald-500" />,
    },
    {
      id: 4,
      action: 'Lembrete enviado',
      patient: 'Roberto Alves',
      time: 'há 1 dia',
      icon: <Bell className="h-4 w-4 text-amber-500" />,
    },
  ]

  const handleQuickAction = (action: string) => {
    toast({
      title: 'Ação rápida',
      description: `${action} em desenvolvimento...`,
    })
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Olá, {user?.name || 'Usuário'}! 👋
          </h1>
          <p className="text-muted-foreground">
            {format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={() => handleQuickAction('Nova consulta')}>
            <Calendar className="mr-2 h-4 w-4" />
            Nova Consulta
          </Button>
          <Button variant="outline" onClick={() => handleQuickAction('Adicionar paciente')}>
            <Users className="mr-2 h-4 w-4" />
            Adicionar Paciente
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <div className={`p-2 rounded-full ${stat.bgColor} ${stat.color}`}>
                {stat.icon}
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground mt-1">
                <span className="text-green-600 font-medium">{stat.change}</span>{' '}
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left Column - Appointments */}
        <div className="lg:col-span-2 space-y-6">
          {/* Upcoming Appointments */}
          <Card>
            <CardHeader>
              <CardTitle>Próximas Consultas</CardTitle>
              <CardDescription>
                Suas consultas agendadas para hoje e amanhã
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingAppointments.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="bg-moss-100 p-2 rounded-md">
                        <Clock className="h-4 w-4 text-moss-600" />
                      </div>
                      <div>
                        <p className="font-medium">{appointment.patient}</p>
                        <p className="text-sm text-muted-foreground">
                          {appointment.time} • {appointment.type}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        appointment.status === 'Confirmado'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {appointment.status}
                      </span>
                      <Button variant="ghost" size="sm">
                        Ver
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Ações Rápidas</CardTitle>
              <CardDescription>
                Acesse rapidamente as funcionalidades mais usadas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: 'Agendar Consulta', icon: Calendar, color: 'bg-blue-100 text-blue-600' },
                  { label: 'Cadastrar Paciente', icon: Users, color: 'bg-green-100 text-green-600' },
                  { label: 'Emitir Recibo', icon: FileText, color: 'bg-purple-100 text-purple-600' },
                  { label: 'Enviar Lembrete', icon: Bell, color: 'bg-amber-100 text-amber-600' },
                ].map((action, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickAction(action.label)}
                    className="flex flex-col items-center justify-center p-4 border rounded-lg hover:bg-muted transition-colors"
                  >
                    <div className={`p-3 rounded-full mb-2 ${action.color}`}>
                      <action.icon className="h-5 w-5" />
                    </div>
                    <span className="text-sm font-medium text-center">{action.label}</span>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Recent Activity */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Atividade Recente</CardTitle>
              <CardDescription>
                Últimas ações no sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start space-x-3">
                    <div className="mt-1">{activity.icon}</div>
                    <div className="flex-1 space-y-1">
                      <p className="text-sm font-medium">{activity.action}</p>
                      <p className="text-sm text-muted-foreground">
                        {activity.patient} • {activity.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Trial Status */}
          {user?.trialEndsAt && (
            <Card className="bg-gradient-to-br from-moss-50 to-beige-50 border-moss-200">
              <CardHeader>
                <CardTitle className="text-moss-800">Período de Teste</CardTitle>
                <CardDescription className="text-moss-600">
                  Você está no período de teste gratuito
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Tempo restante</span>
                      <span className="font-semibold">5 dias</span>
                    </div>
                    <div className="h-2 bg-moss-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-moss-500 to-moss-600 rounded-full"
                        style={{ width: '70%' }}
                      />
                    </div>
                  </div>
                  <p className="text-sm text-moss-700">
                    Aproveite todas as funcionalidades do sistema durante o período de teste.
                  </p>
                  <Button className="w-full bg-moss-600 hover:bg-moss-700">
                    <DollarSign className="mr-2 h-4 w-4" />
                    Escolher Plano
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* System Status */}
          <Card>
            <CardHeader>
              <CardTitle>Status do Sistema</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { label: 'API WhatsApp', status: 'online', color: 'bg-green-500' },
                  { label: 'Google Agenda', status: 'connected', color: 'bg-green-500' },
                  { label: 'Banco de Dados', status: 'online', color: 'bg-green-500' },
                  { label: 'Backups', status: 'ativo', color: 'bg-green-500' },
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm">{item.label}</span>
                    <div className="flex items-center space-x-2">
                      <div className={`h-2 w-2 rounded-full ${item.color}`} />
                      <span className="text-xs text-muted-foreground">{item.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}