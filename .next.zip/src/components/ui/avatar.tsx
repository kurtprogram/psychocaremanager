import * as React from 'react'

export function Avatar({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props}>{children}</div>
}

export function AvatarImage({ ...props }: React.ImgHTMLAttributes<HTMLImageElement>) {
  return <img {...props} />
}

export function AvatarFallback({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props}>{children}</div>
}
