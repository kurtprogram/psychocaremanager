import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import { authConfig } from '@/lib/auth'

const updateAppointmentSchema = z.object({
  title: z.string().min(3, 'Título muito curto').optional(),
  description: z.string().optional(),
  startTime: z.string().datetime().optional(),
  endTime: z.string().datetime().optional(),
  type: z.enum(['IN_PERSON', 'ONLINE']).optional(),
  location: z.string().optional(),
  meetingLink: z.string().url().optional().or(z.literal('')),
  notes: z.string().optional(),
  status: z.enum(['SCHEDULED', 'CONFIRMED', 'CANCELLED', 'COMPLETED']).optional(),
})

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const appointment = await prisma.appointment.findUnique({
      where: {
        id: params.id,
        organizationId: session.user.organizationId,
        deletedAt: null,
      },
      include: {
        patient: {
          select: {
            id: true,
            fullName: true,
            phone: true,
            email: true,
          },
        },
        professional: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
          },
        },
      },
    })

    if (!appointment) {
      return NextResponse.json(
        { error: 'Consulta não encontrada' },
        { status: 404 }
      )
    }

    return NextResponse.json(appointment)
  } catch (error) {
    console.error('Error fetching appointment:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar consulta' },
      { status: 500 }
    )
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const body = await req.json()
    const validated = updateAppointmentSchema.parse(body)

    // Buscar consulta atual
    const currentAppointment = await prisma.appointment.findUnique({
      where: {
        id: params.id,
        organizationId: session.user.organizationId,
      },
    })

    if (!currentAppointment) {
      return NextResponse.json(
        { error: 'Consulta não encontrada' },
        { status: 404 }
      )
    }

    // Atualizar consulta
    const appointment = await prisma.appointment.update({
      where: {
        id: params.id,
        organizationId: session.user.organizationId,
      },
      data: {
        ...validated,
        ...(validated.startTime && { startTime: new Date(validated.startTime) }),
        ...(validated.endTime && { endTime: new Date(validated.endTime) }),
      },
      include: {
        patient: true,
        professional: true,
      },
    })

    // Log de auditoria
    await prisma.auditLog.create({
      data: {
        organizationId: session.user.organizationId,
        userId: session.user.id,
        userEmail: session.user.email!,
        userName: session.user.name!,
        action: 'UPDATE',
        entityType: 'APPOINTMENT',
        entityId: appointment.id,
        before: currentAppointment,
        after: appointment,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    // Notificar se status mudou
    if (validated.status && validated.status !== currentAppointment.status) {
      await prisma.notification.create({
        data: {
          organizationId: session.user.organizationId,
          patientId: appointment.patientId,
          type: 'APPOINTMENT_STATUS_CHANGED',
          channel: 'WHATSAPP',
          title: 'Status da Consulta Atualizado',
          message: `Sua consulta com ${appointment.professional.name} agora está ${validated.status === 'CONFIRMED' ? 'confirmada' : 'cancelada'}.`,
          status: 'PENDING',
        },
      })
    }

    return NextResponse.json({
      success: true,
      appointment,
    })

  } catch (error: any) {
    console.error('Error updating appointment:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Erro ao atualizar consulta' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const appointment = await prisma.appointment.findUnique({
      where: {
        id: params.id,
        organizationId: session.user.organizationId,
      },
    })

    if (!appointment) {
      return NextResponse.json(
        { error: 'Consulta não encontrada' },
        { status: 404 }
      )
    }

    // Soft delete
    await prisma.appointment.update({
      where: {
        id: params.id,
        organizationId: session.user.organizationId,
      },
      data: {
        deletedAt: new Date(),
        status: 'CANCELLED',
      },
    })

    // Log de auditoria
    await prisma.auditLog.create({
      data: {
        organizationId: session.user.organizationId,
        userId: session.user.id,
        userEmail: session.user.email!,
        userName: session.user.name!,
        action: 'DELETE',
        entityType: 'APPOINTMENT',
        entityId: params.id,
        before: appointment,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    return NextResponse.json({
      success: true,
      message: 'Consulta cancelada com sucesso',
    })

  } catch (error) {
    console.error('Error deleting appointment:', error)
    return NextResponse.json(
      { error: 'Erro ao cancelar consulta' },
      { status: 500 }
    )
  }
}