declare module '@radix-ui/react-switch' {
  import * as React from 'react'
  export const Root: React.ComponentType<any>
  export const Thumb: React.ComponentType<any>
  export default Root
}

declare module '@radix-ui/react-progress' {
  import * as React from 'react'
  export const Root: React.ComponentType<any>
  export const Indicator: React.ComponentType<any>
  export default Root
}

declare module 'stripe' {
  class Stripe {
    constructor(secret: string, opts?: any)
    customers: any
    subscriptions: any
    checkout: any
    paymentIntents: any
    static webhooks: {
      constructEvent(body: string, sig: string, secret: string): any
      signature?: any
    }
  }
  namespace Stripe {
    export interface Subscription { id: string; status?: string; customer?: string | null; current_period_end?: number; ended_at?: number }
    export interface Event { type: string; data: { object: any } }
    export interface Invoice { customer?: any; amount_paid: number; currency: string; due_date?: number | null; created: number; payment_intent?: string; id?: string; number?: string }
    export namespace Checkout {
      export interface Session { customer?: string | null; subscription?: string | null; [key: string]: any }
    }
  }
  export default Stripe
}

declare module 'googleapis' {
  export const google: any
}

declare module 'google-auth-library' {
  export class OAuth2Client {
    constructor(...args: any[])
    generateAuthUrl(opts?: any): string
    getToken(code: string): Promise<{ tokens: any }>
    setCredentials(tokens: any): void
  }
}

declare module 'socket.io' {
  export class Server { constructor(httpServer?: any, opts?: any); on(event: string, cb: any): any; to(room: string): any; }
}
