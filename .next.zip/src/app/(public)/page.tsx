import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { CheckCircle, Calendar, Users, FileText, Shield, Globe } from 'lucide-react'

export default function HomePage() {
  const features = [
    {
      icon: <Calendar className="h-8 w-8" />,
      title: 'Agendamento Inteligente',
      description: 'Agende consultas com integração ao Google Agenda e lembretes automáticos por WhatsApp.'
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: 'Gestão de Pacientes',
      description: 'Organize prontuários, histórico de consultas e informações médicas em um só lugar.'
    },
    {
      icon: <FileText className="h-8 w-8" />,
      title: 'Prontuários Eletrônicos',
      description: 'Prontuários seguros e organizados com criptografia de ponta a ponta.'
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: 'Conformidade LGPD',
      description: 'Totalmente adequado à legislação de proteção de dados brasileira.'
    },
    {
      icon: <Globe className="h-8 w-8" />,
      title: 'Multi-idioma',
      description: 'Disponível em Português, Inglês e Espanhol para atender diversos profissionais.'
    }
  ]

  const plans = [
    {
      name: 'Individual',
      price: 'R$ 79/mês',
      description: 'Para psicólogos autônomos',
      features: [
        'Agendamento ilimitado',
        'Até 100 pacientes',
        'Integração Google Agenda',
        'WhatsApp automático',
        'Prontuários eletrônicos',
        'Relatórios básicos'
      ]
    },
    {
      name: 'Clínica',
      price: 'R$ 199/mês',
      description: 'Para clínicas com até 10 profissionais',
      features: [
        'Tudo do plano Individual',
        'Até 10 profissionais',
        'Agendas compartilhadas',
        'Gestão hierárquica',
        'Relatórios avançados',
        'Suporte prioritário'
      ],
      popular: true
    },
    {
      name: 'Empresarial',
      price: 'Personalizado',
      description: 'Para empresas e grandes clínicas',
      features: [
        'Tudo do plano Clínica',
        'Profissionais ilimitados',
        'API personalizada',
        'Treinamento dedicado',
        'Suporte 24/7',
        'Customização avançada'
      ]
    }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-moss-50 to-background py-20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground mb-6">
              Gestão Completa para{' '}
              <span className="text-moss-600">Psicólogos</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Sistema SaaS profissional para psicólogos autônomos, clínicas e empresas. 
              Tudo que você precisa para gerenciar sua prática em um só lugar.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link href="/cadastro">
                  Começar Teste Grátis
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/planos">
                  Ver Planos
                </Link>
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              Teste gratuito de 7 dias. Não precisa de cartão de crédito.
            </p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Funcionalidades Completas</h2>
            <p className="text-lg text-muted-foreground">
              Tudo que você precisa para uma gestão eficiente da sua prática psicológica
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="border-border hover:border-moss-300 transition-colors">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-moss-100 flex items-center justify-center text-moss-600 mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle>{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Plans Section */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Planos que Cabe no Seu Bolso</h2>
            <p className="text-lg text-muted-foreground">
              Escolha o plano ideal para suas necessidades
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <Card 
                key={index} 
                className={`relative ${plan.popular ? 'border-moss-300 shadow-lg' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-moss-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                      Mais Popular
                    </span>
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-bold">{plan.price}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-moss-500" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full mt-6" asChild>
                    <Link href="/cadastro">
                      Começar Agora
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">
              Pronto para Transformar sua Gestão?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Junte-se a milhares de psicólogos que já otimizaram sua prática com o PsicoGestão.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="px-8" asChild>
                <Link href="/cadastro">
                  Começar Teste Grátis
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/login">
                  Fazer Login
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-lg font-semibold">PsicoGestão</h3>
              <p className="text-sm text-muted-foreground">
                Plataforma de Gestão para Psicólogos
              </p>
            </div>
            <div className="flex gap-6">
              <Link href="/termos" className="text-sm hover:text-moss-600">
                Termos de Uso
              </Link>
              <Link href="/privacidade" className="text-sm hover:text-moss-600">
                Política de Privacidade
              </Link>
              <Link href="/lgpd" className="text-sm hover:text-moss-600">
                LGPD
              </Link>
              <Link href="/contato" className="text-sm hover:text-moss-600">
                Contato
              </Link>
            </div>
          </div>
          <div className="text-center mt-8 text-sm text-muted-foreground">
            <p>© {new Date().getFullYear()} PsicoGestão. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}