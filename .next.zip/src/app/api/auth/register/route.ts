import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'
import { emailSchema } from '@/lib/validation'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { name, email, password, phone, planType, clinicName, normalizedEmail } = body

    // 1. Validação de email (já feita no middleware, mas fazemos de novo por segurança)
    const emailValidation = emailSchema.safeParse(email)
    if (!emailValidation.success) {
      return NextResponse.json(
        { error: emailValidation.error.errors[0].message },
        { status: 400 }
      )
    }

    // 2. Para Gmail, usar email normalizado para verificação de duplicidade
    const emailToCheck = normalizedEmail || email
    
    // 3. Verificar se email já existe (com normalização para Gmail)
    const existingUser = await prisma.user.findFirst({
      where: {
        OR: [
          { email: emailToCheck },
          ...(email.includes('@gmail.com') ? [
            { 
              email: {
                contains: '@gmail.com',
                mode: 'insensitive'
              }
            }
          ] : [])
        ]
      },
    })

    if (existingUser) {
      // Se for Gmail, verificar se é o mesmo email normalizado
      if (email.includes('@gmail.com')) {
        const existingGmailUser = existingUser.email.split('@')[0].toLowerCase().replace(/\./g, '')
        const newGmailUser = email.split('@')[0].toLowerCase().replace(/\./g, '')
        
        if (existingGmailUser === newGmailUser) {
          return NextResponse.json(
            { error: 'Este email do Gmail já está cadastrado' },
            { status: 400 }
          )
        }
      } else {
        return NextResponse.json(
          { error: 'Este email já está cadastrado' },
          { status: 400 }
        )
      }
    }

    // 4. Verificar força do email (opcional - para analytics)
    const emailDomain = email.split('@')[1]?.toLowerCase() || ''
    const emailStrength = getEmailStrength(email)

    // 5. Hash da senha
    const hashedPassword = await bcrypt.hash(password, 12)

    // 6. Criar organização
    const organization = await prisma.organization.create({
      data: {
        name: clinicName || `${name} - Consultório`,
        type: planType,
        status: 'TRIAL',
        trialEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        maxProfessionals: planType === 'CLINIC' ? 10 : planType === 'ENTERPRISE' ? null : 1,
        maxPatients: 100,
        settings: {
          emailValidation: emailStrength,
          autoVerifyCorporate: emailDomain.includes('clinica') || emailDomain.includes('hospital'),
        },
        features: {
          patientArea: true,
          reports: true,
          financial: true,
          whatsapp: true,
        },
      },
    })

    // 7. Criar usuário
    const user = await prisma.user.create({
      data: {
        name,
        email: emailToCheck, // Usar email normalizado
        originalEmail: email, // Salvar email original
        passwordHash: hashedPassword,
        phone,
        whatsapp: phone,
        role: planType === 'INDIVIDUAL' ? 'PSYCHOLOGIST' : 'ADMIN',
        organizationId: organization.id,
        emailVerified: emailStrength === 'high' ? new Date() : null,
        metadata: {
          emailStrength,
          emailDomain,
          signupSource: 'web',
        },
      },
    })

    // 8. Registrar analytics de email
    await prisma.auditLog.create({
      data: {
        organizationId: organization.id,
        userId: user.id,
        userEmail: user.email!,
        userName: user.name!,
        action: 'SIGNUP',
        entityType: 'USER',
        entityId: user.id,
        data: {
          emailStrength,
          emailDomain,
          planType,
          hasCorporateEmail: emailDomain.includes('clinica') || emailDomain.includes('hospital'),
        },
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    // 9. Enviar email de verificação se necessário
    if (emailStrength !== 'high') {
      await prisma.notification.create({
        data: {
          organizationId: organization.id,
          userId: user.id,
          type: 'EMAIL_VERIFICATION',
          channel: 'EMAIL',
          title: 'Verifique seu email',
          message: 'Por favor, verifique seu email para confirmar sua conta.',
          status: 'PENDING',
        },
      })
    }

    return NextResponse.json({
      success: true,
      userId: user.id,
      organizationId: organization.id,
      trialEndsAt: organization.trialEndsAt,
      emailVerified: !!user.emailVerified,
      requiresVerification: emailStrength !== 'high',
    })

  } catch (error: any) {
    console.error('Registration error:', error)
    
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

// Função auxiliar
function getEmailStrength(email: string): 'high' | 'medium' | 'low' {
  const domain = email.split('@')[1]?.toLowerCase() || ''
  
  // Domínios corporativos
  if (domain.includes('clinica') || domain.includes('hospital') || 
      domain.includes('saude') || domain.includes('med')) {
    return 'high'
  }
  
  // Domínios conhecidos
  const trustedDomains = ['gmail.com', 'outlook.com', 'hotmail.com', 'yahoo.com', 'icloud.com']
  if (trustedDomains.includes(domain)) {
    return 'medium'
  }
  
  // Domínios .com.br são considerados médios
  if (domain.endsWith('.com.br') || domain.endsWith('.br')) {
    return 'medium'
  }
  
  return 'low'
}