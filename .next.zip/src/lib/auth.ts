import { NextAuthConfig } from 'next-auth'
import { type DefaultSession } from 'next-auth'
import { PrismaAdapter } from '@auth/prisma-adapter'
import Google from 'next-auth/providers/google'
import Credentials from 'next-auth/providers/credentials'
import { prisma } from './prisma'
import * as bcrypt from 'bcryptjs'
import { z } from 'zod'

declare module 'next-auth' {
  interface User {
    role?: string
    organizationId?: string
  }
  interface Session {
    user: {
      id?: string
      role?: string
      organizationId?: string
    } & DefaultSession['user']
  }
}



const credentialsSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
})

export const authConfig = {
  adapter: PrismaAdapter(prisma),
  session: {
    strategy: 'jwt' as const,
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  pages: {
    signIn: '/login',
    error: '/auth-error',
    verifyRequest: '/verificar-email',
    newUser: '/onboarding',
  },
  callbacks: {
    async jwt({ token, user, trigger, session }) {
      if (user) {
        token.id = user.id
        token.role = (user as any).role || 'PATIENT'
        token.organizationId = (user as any).organizationId || null
      }
      
      if (trigger === 'update' && session) {
        token = { ...token, ...session }
      }
      
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string
        session.user.role = token.role as string
        session.user.organizationId = token.organizationId as string
      }
      return session
    },
    async signIn({ user, account, profile }) {
      // Prevent sign in for deleted users
      const dbUser = await prisma.user.findUnique({
        where: { id: user.id },
        select: { deletedAt: true }
      })
      
      if (dbUser?.deletedAt) {
        return false
      }
      
      // Log the sign in attempt
      await prisma.auditLog.create({
        data: {
          userId: user.id,
          userEmail: user.email!,
          userName: user.name!,
          action: 'LOGIN',
          entityType: 'USER',
          entityId: user.id,
          ipAddress: 'unknown',
          userAgent: 'unknown',
        }
      })
      
      return true
    },
  },
  providers: [
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      allowDangerousEmailAccountLinking: true,
    }),
    Credentials({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Senha', type: 'password' },
      },
      async authorize(credentials) {
        try {
          const validated = credentialsSchema.parse(credentials)
          
          const user = await prisma.user.findUnique({
            where: { email: validated.email },
            select: {
              id: true,
              email: true,
              name: true,
              passwordHash: true,
              role: true,
              organizationId: true,
              deletedAt: true,
            }
          })
          
          if (!user || user.deletedAt) {
            return null
          }
          
          if (!user.passwordHash) {
            throw new Error('Usuário não possui senha cadastrada. Use login social.')
          }
          
          const isValid = await bcrypt.compare(validated.password, user.passwordHash)
          
          if (!isValid) {
            return null
          }
          
          return {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            organizationId: user.organizationId,
          }
        } catch (error) {
          console.error('Auth error:', error)
          return null
        }
      },
    }),
  ],
  events: {
    async createUser({ user }) {
      // Create audit log for new user
      await prisma.auditLog.create({
        data: {
          userId: user.id,
          userEmail: user.email!,
          userName: user.name || 'Unknown',
          action: 'CREATE',
          entityType: 'USER',
          entityId: user.id,
          ipAddress: 'unknown',
          userAgent: 'unknown',
        }
      })
    },
  },
} satisfies NextAuthConfig