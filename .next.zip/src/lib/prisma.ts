import { PrismaClient } from '@prisma/client'

declare global {
  // allow global caching of the prisma client in development
  // eslint-disable-next-line no-var
  var prisma: PrismaClient | undefined
}

export const prisma = globalThis.prisma ?? new PrismaClient()
if (process.env.NODE_ENV !== 'production') globalThis.prisma = prisma

// Prisma middleware for audit logging
prisma.$use(async (params: any, next: any) => {
  const start = Date.now()
  const result = await next(params)
  const duration = Date.now() - start

  // Log slow queries
  if (duration > 1000) {
    console.warn(`Slow query detected: ${params.model}.${params.action} took ${duration}ms`)
  }

  return result
})

// Soft delete middleware (basic safe defaults)
prisma.$use(async (params: any, next: any) => {
  try {
    if (params.action === 'findUnique' || params.action === 'findFirst') {
      params.action = 'findFirst'
      params.args.where = { ...params.args.where, deletedAt: null }
    }

    if (params.action === 'findMany') {
      if (!params.args.where) {
        params.args.where = { deletedAt: null }
      } else {
        params.args.where.deletedAt = null
      }
    }

    if (params.action === 'update' || params.action === 'updateMany') {
      if (!params.args.where) params.args.where = {}
      params.args.where.deletedAt = null
    }

    if (params.action === 'delete') {
      params.action = 'update'
      params.args.data = { deletedAt: new Date() }
    }

    if (params.action === 'deleteMany') {
      params.action = 'updateMany'
      if (!params.args.where) params.args.where = { deletedAt: null }
      params.args.data = { deletedAt: new Date() }
    }
  } catch (e) {
    // ignore and continue
  }

  return next(params)
})