'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import {
  Calendar,
  Users,
  FileText,
  DollarSign,
  BarChart,
  Bell,
  Settings,
  Home,
  Building,
  User,
  ChevronLeft,
  ChevronRight,
  LogOut,
  MessageSquare,
  Target,
  BookOpen,
} from 'lucide-react'
import { signOut } from 'next-auth/react'

interface DashboardSidebarProps {
  isOpen: boolean
  onToggle: () => void
  userRole: string
}

type MenuItem = { title: string; href: string; icon: any; badge?: number }

const menuItems: MenuItem[] = [
  {
    title: 'Dashboard',
    href: '/dashboard',
    icon: Home,
  },
  {
    title: 'Agenda',
    href: '/agenda',
    icon: Calendar,
  },
  {
    title: 'Pacientes',
    href: '/pacientes',
    icon: Users,
  },
  {
    title: 'Prontuários',
    href: '/prontuarios',
    icon: FileText,
  },
  {
    title: 'Financeiro',
    href: '/financeiro',
    icon: DollarSign,
  },
  {
    title: 'Relatórios',
    href: '/relatorios',
    icon: BarChart,
  },
  {
    title: 'Notificações',
    href: '/notificacoes',
    icon: Bell,
    badge: 3,
  },
]

const clinicMenuItems: MenuItem[] = [
  {
    title: 'Profissionais',
    href: '/clinica/profissionais',
    icon: Users,
  },
  {
    title: 'Pacientes',
    href: '/clinica/pacientes',
    icon: Users,
  },
  {
    title: 'Agenda',
    href: '/clinica/agenda',
    icon: Calendar,
  },
  {
    title: 'Relatórios',
    href: '/clinica/relatorios',
    icon: BarChart,
  },
]

const adminMenuItems: MenuItem[] = [
  {
    title: 'Usuários',
    href: '/admin/usuarios',
    icon: Users,
  },
  {
    title: 'Planos',
    href: '/admin/planos',
    icon: DollarSign,
  },
  {
    title: 'Clínicas',
    href: '/admin/clinicas',
    icon: Building,
  },
  {
    title: 'Logs',
    href: '/admin/logs',
    icon: FileText,
  },
]

export default function DashboardSidebar({ isOpen, onToggle, userRole }: DashboardSidebarProps) {
  const pathname = usePathname()
  const [activeMenu, setActiveMenu] = useState('dashboard')

  const handleSignOut = async () => {
    await signOut({ callbackUrl: '/login' })
  }

  const getMenuItems = () => {
    if (userRole === 'SUPER_ADMIN') return [...menuItems, ...adminMenuItems]
    if (userRole === 'ADMIN') return [...menuItems, ...clinicMenuItems]
    if (userRole === 'PSYCHOLOGIST') return menuItems
    if (userRole === 'RECEPTIONIST') return menuItems.filter(item => 
      ['/dashboard', '/agenda'].includes(item.href)
    )
    return []
  }

  const menuToShow = getMenuItems()

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 z-40 h-screen border-r bg-background transition-all duration-300',
        isOpen ? 'w-64' : 'w-20'
      )}
    >
      {/* Sidebar Header */}
      <div className="flex h-16 items-center justify-between border-b px-4">
        <Link 
          href="/dashboard" 
          className={cn(
            'flex items-center space-x-2 font-semibold',
            !isOpen && 'justify-center w-full'
          )}
        >
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-moss-500 to-moss-700 flex items-center justify-center">
            <span className="text-white font-bold">P</span>
          </div>
          {isOpen && <span className="text-lg">PsicoGestão</span>}
        </Link>
        
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggle}
          className="h-8 w-8"
        >
          {isOpen ? (
            <ChevronLeft className="h-4 w-4" />
          ) : (
            <ChevronRight className="h-4 w-4" />
          )}
        </Button>
      </div>

      {/* Sidebar Content */}
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-2">
          {menuToShow.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(item.href)
            
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setActiveMenu(item.href)}
                className={cn(
                  'flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-moss-100 text-moss-900'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                )}
              >
                <item.icon className={cn('h-5 w-5', isActive ? 'text-moss-600' : '')} />
                {isOpen && (
                  <>
                    <span className="ml-3 flex-1">{item.title}</span>
                    {item.badge && (
                      <span className="ml-auto inline-flex h-5 w-5 items-center justify-center rounded-full bg-moss-600 text-xs text-white">
                        {item.badge}
                      </span>
                    )}
                  </>
                )}
              </Link>
            )
          })}

          {/* Patient Area Link */}
          {userRole === 'PSYCHOLOGIST' && isOpen && (
            <div className="pt-6">
              <div className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Área do Paciente
              </div>
              <div className="space-y-1">
                <Link
                  href="/paciente"
                  className="flex items-center rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                >
                  <Target className="h-5 w-5 mr-3" />
                  {isOpen && 'Missões'}
                </Link>
                <Link
                  href="/paciente/trilhas"
                  className="flex items-center rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                >
                  <BookOpen className="h-5 w-5 mr-3" />
                  {isOpen && 'Trilhas de Aprendizado'}
                </Link>
              </div>
            </div>
          )}

          {/* Settings */}
          <div className="pt-6">
            <Link
              href="/configuracoes"
              className={cn(
                'flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                pathname === '/configuracoes'
                  ? 'bg-moss-100 text-moss-900'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              )}
            >
              <Settings className="h-5 w-5" />
              {isOpen && <span className="ml-3">Configurações</span>}
            </Link>

            <Link
              href="/configuracoes/whatsapp"
              className={cn(
                'flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                pathname === '/configuracoes/whatsapp'
                  ? 'bg-moss-100 text-moss-900'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              )}
            >
              <MessageSquare className="h-5 w-5" />
              {isOpen && <span className="ml-3">WhatsApp</span>}
            </Link>
          </div>
        </nav>
      </div>

      {/* Sidebar Footer */}
      <div className="border-t p-4">
        <div className="flex items-center justify-between">
          <Link
            href="/perfil"
            className="flex items-center space-x-2 text-sm hover:text-foreground"
          >
            <div className="h-8 w-8 rounded-full bg-moss-100 flex items-center justify-center">
              <User className="h-4 w-4 text-moss-600" />
            </div>
            {isOpen && (
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">Meu Perfil</p>
              </div>
            )}
          </Link>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={handleSignOut}
            className="h-8 w-8"
            title="Sair"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </aside>
  )
}