import { NextRequest, NextResponse } from 'next/server'
import { emailSchema } from '@/lib/validation'

export async function emailValidationMiddleware(req: NextRequest) {
  // Apenas para rotas de registro/login
  if (!req.nextUrl.pathname.includes('/api/auth/')) {
    return NextResponse.next()
  }

  try {
    const body = await req.clone().json()
    
    if (body.email) {
      const result = emailSchema.safeParse(body.email)
      
      if (!result.success) {
        return NextResponse.json(
          { 
            error: 'Email inválido',
            details: result.error.errors 
          },
          { status: 400 }
        )
      }

      // Verificação adicional para Gmail
      if (body.email.includes('@gmail.com')) {
        // Normalizar Gmail (remove pontos e ignora maiúsculas)
        const [user, domain] = body.email.split('@')
        const normalizedEmail = `${user.toLowerCase().replace(/\./g, '')}@${domain}`
        
        // Adicionar email normalizado ao request
        const newBody = { ...body, normalizedEmail }
        const newReq = new NextRequest(req, {
          body: JSON.stringify(newBody)
        })
        
        return NextResponse.next({
          request: newReq
        })
      }
    }
    
    return NextResponse.next()
  } catch (error) {
    // Se não for JSON ou não tiver email, continua
    return NextResponse.next()
  }
}