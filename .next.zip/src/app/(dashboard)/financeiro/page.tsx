'use client'

import { useState } from 'react'
import { DollarSign, TrendingUp, CreditCard, PiggyBank, Filter, Download, Plus, CheckCircle, Clock, AlertCircle, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/hooks/useToast'
import { formatCurrency } from '@/lib/utils'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

const paymentsData = [
  {
    id: 1,
    patient: 'João Silva',
    date: '2024-01-15',
    amount: 250.00,
    method: 'PIX',
    status: 'paid',
    dueDate: '2024-01-15',
    description: 'Consulta 05/12'
  },
  {
    id: 2,
    patient: 'Maria Santos',
    date: '2024-01-14',
    amount: 300.00,
    method: 'INSURANCE',
    status: 'pending',
    dueDate: '2024-01-20',
    description: 'Consulta 12/12'
  },
  {
    id: 3,
    patient: 'Pedro Oliveira',
    date: '2024-01-10',
    amount: 250.00,
    method: 'CASH',
    status: 'paid',
    dueDate: '2024-01-10',
    description: 'Consulta 05/01'
  },
  {
    id: 4,
    patient: 'Ana Costa',
    date: '2024-01-05',
    amount: 280.00,
    method: 'CREDIT_CARD',
    status: 'overdue',
    dueDate: '2024-01-01',
    description: 'Consulta 28/12'
  },
]

export default function FinanceiroPage() {
  const { toast } = useToast()
  const [period, setPeriod] = useState('month')
  const [filter, setFilter] = useState('all')

  const revenueData = {
    total: 12580.00,
    thisMonth: 3240.00,
    pending: 1560.00,
    overdue: 280.00
  }

  const handleNewPayment = () => {
    toast({
      title: 'Novo pagamento',
      description: 'Abrindo formulário...',
    })
  }

  const handleExport = () => {
    toast({
      title: 'Exportando relatório',
      description: 'Gerando arquivo...',
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" /> Pago</Badge>
      case 'pending':
        return <Badge className="bg-amber-100 text-amber-800"><Clock className="h-3 w-3 mr-1" /> Pendente</Badge>
      case 'overdue':
        return <Badge className="bg-red-100 text-red-800"><AlertCircle className="h-3 w-3 mr-1" /> Atrasado</Badge>
      default:
        return <Badge>Desconhecido</Badge>
    }
  }

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'PIX':
        return <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">P</div>
      case 'INSURANCE':
        return <PiggyBank className="h-4 w-4 text-blue-600" />
      case 'CASH':
        return <DollarSign className="h-4 w-4 text-emerald-600" />
      case 'CREDIT_CARD':
        return <CreditCard className="h-4 w-4 text-purple-600" />
      default:
        return <DollarSign className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Financeiro</h1>
          <p className="text-muted-foreground">
            Controle de pagamentos e receitas
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={handleNewPayment}>
            <Plus className="mr-2 h-4 w-4" />
            Novo Pagamento
          </Button>
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Dashboard Financeiro */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(revenueData.total)}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+12.5%</span> vs mês passado
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Este Mês</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(revenueData.thisMonth)}</div>
            <p className="text-xs text-muted-foreground">
              Meta: {formatCurrency(4000)} (81%)
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            <Clock className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(revenueData.pending)}</div>
            <p className="text-xs text-muted-foreground">5 pagamentos</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Atrasados</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(revenueData.overdue)}</div>
            <p className="text-xs text-muted-foreground">1 pagamento</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="payments" className="w-full">
        <TabsList className="grid w-full md:w-auto grid-cols-3 md:inline-flex">
          <TabsTrigger value="payments">Pagamentos</TabsTrigger>
          <TabsTrigger value="invoices">Faturas</TabsTrigger>
          <TabsTrigger value="reports">Relatórios</TabsTrigger>
        </TabsList>

        <TabsContent value="payments" className="space-y-6 mt-6">
          {/* Filtros */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Período</label>
                    <Select value={period} onValueChange={setPeriod}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="today">Hoje</SelectItem>
                        <SelectItem value="week">Esta semana</SelectItem>
                        <SelectItem value="month">Este mês</SelectItem>
                        <SelectItem value="quarter">Este trimestre</SelectItem>
                        <SelectItem value="year">Este ano</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Status</label>
                    <Select value={filter} onValueChange={setFilter}>
                      <SelectTrigger>
                        <SelectValue placeholder="Todos" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos</SelectItem>
                        <SelectItem value="paid">Pagos</SelectItem>
                        <SelectItem value="pending">Pendentes</SelectItem>
                        <SelectItem value="overdue">Atrasados</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-end">
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Mais Filtros
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tabela de Pagamentos */}
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Pagamentos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Paciente</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Vencimento</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Método</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paymentsData.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell className="font-medium">{payment.patient}</TableCell>
                        <TableCell>
                          {format(new Date(payment.date), 'dd/MM/yyyy')}
                        </TableCell>
                        <TableCell>
                          {format(new Date(payment.dueDate), 'dd/MM/yyyy')}
                        </TableCell>
                        <TableCell className="font-semibold">
                          {formatCurrency(payment.amount)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getMethodIcon(payment.method)}
                            <span className="capitalize">{payment.method.toLowerCase().replace('_', ' ')}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(payment.status)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button size="sm" variant="ghost">
                              Editar
                            </Button>
                            {payment.status === 'pending' && (
                              <Button size="sm">
                                Marcar como Pago
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="invoices" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Faturas e Recibos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold">Sistema de Faturas</h3>
                <p className="text-muted-foreground mt-2 mb-6">
                  Em desenvolvimento - Em breve você poderá gerar faturas e recibos automaticamente
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Criar Fatura
                  </Button>
                  <Button variant="outline">
                    Modelos
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Métodos de Pagamento */}
      <Card>
        <CardHeader>
          <CardTitle>Métodos de Pagamento Aceitos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="flex flex-col items-center p-4 border rounded-lg">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-3">
                <span className="text-green-700 font-bold">PIX</span>
              </div>
              <h4 className="font-semibold">PIX</h4>
              <p className="text-sm text-muted-foreground text-center">Pagamento instantâneo</p>
              <Badge className="mt-2 bg-green-100 text-green-800">Ativo</Badge>
            </div>
            
            <div className="flex flex-col items-center p-4 border rounded-lg">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-3">
                <PiggyBank className="h-6 w-6 text-blue-600" />
              </div>
              <h4 className="font-semibold">Convênios</h4>
              <p className="text-sm text-muted-foreground text-center">Várias operadoras</p>
              <Badge className="mt-2 bg-blue-100 text-blue-800">Ativo</Badge>
            </div>
            
            <div className="flex flex-col items-center p-4 border rounded-lg">
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-3">
                <CreditCard className="h-6 w-6 text-purple-600" />
              </div>
              <h4 className="font-semibold">Cartão</h4>
              <p className="text-sm text-muted-foreground text-center">Crédito/Débito</p>
              <Badge variant="outline" className="mt-2">Em breve</Badge>
            </div>
            
            <div className="flex flex-col items-center p-4 border rounded-lg">
              <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mb-3">
                <DollarSign className="h-6 w-6 text-emerald-600" />
              </div>
              <h4 className="font-semibold">Dinheiro</h4>
              <p className="text-sm text-muted-foreground text-center">Pagamento em espécie</p>
              <Badge className="mt-2 bg-emerald-100 text-emerald-800">Ativo</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}