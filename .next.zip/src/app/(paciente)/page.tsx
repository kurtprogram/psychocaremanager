'use client'

import { useState } from 'react'
import { Target, BookOpen, Calendar, Award, TrendingUp, Clock, CheckCircle, Star, ArrowRight } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { useToast } from '@/hooks/useToast'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import Link from 'next/link'

const missions = [
  {
    id: 1,
    title: 'Diário de Emoções',
    description: 'Registrar emoções diárias por 7 dias',
    progress: 85,
    type: 'daily',
    reward: 50,
  },
  {
    id: 2,
    title: 'Exercícios de Respiração',
    description: 'Completar 10 sessões de 5 minutos',
    progress: 40,
    type: 'weekly',
    reward: 100,
  },
  {
    id: 3,
    title: 'Reconhecimento de Pensamentos',
    description: 'Identificar padrões de pensamento automático',
    progress: 20,
    type: 'learning',
    reward: 75,
  },
]

const learningPaths = [
  {
    id: 1,
    title: 'Entendendo a Ansiedade',
    modules: 5,
    completed: 2,
    description: 'Aprenda sobre os mecanismos da ansiedade',
    color: 'bg-blue-100 text-blue-800',
  },
  {
    id: 2,
    title: 'Mindfulness Básico',
    modules: 4,
    completed: 1,
    description: 'Introdução à prática de mindfulness',
    color: 'bg-green-100 text-green-800',
  },
  {
    id: 3,
    title: 'Regulação Emocional',
    modules: 6,
    completed: 0,
    description: 'Estratégias para regular emoções',
    color: 'bg-purple-100 text-purple-800',
  },
]

const appointments = [
  {
    id: 1,
    date: '2024-01-15T09:00:00',
    professional: 'Dra. Maria Silva',
    type: 'online',
    status: 'confirmed',
  },
  {
    id: 2,
    date: '2024-01-22T09:00:00',
    professional: 'Dra. Maria Silva',
    type: 'in_person',
    status: 'scheduled',
  },
]

export default function PatientDashboard() {
  const { toast } = useToast()
  const [points, setPoints] = useState(225)

  const handleMissionComplete = (missionId: number) => {
    toast({
      title: 'Missão concluída!',
      description: '+50 pontos adicionados à sua conta',
    })
    setPoints(points + 50)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Minha Jornada</h1>
          <p className="text-muted-foreground">
            Bem-vindo(a) de volta! Continue sua evolução.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-amber-100 text-amber-800">
            <Star className="h-3 w-3 mr-1" />
            {points} pontos
          </Badge>
          <Button variant="outline" asChild>
            <Link href="/paciente/perfil">
              Meu Perfil
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Coluna Esquerda */}
        <div className="lg:col-span-2 space-y-6">
          {/* Missões */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Minhas Missões
              </CardTitle>
              <CardDescription>
                Complete missões para evoluir na sua jornada
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {missions.map((mission) => (
                  <div
                    key={mission.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold">{mission.title}</h4>
                        <Badge className={mission.type === 'daily' ? 'bg-blue-100 text-blue-800' : 
                                         mission.type === 'weekly' ? 'bg-green-100 text-green-800' : 
                                         'bg-purple-100 text-purple-800'}>
                          {mission.type === 'daily' ? 'Diária' : 
                           mission.type === 'weekly' ? 'Semanal' : 'Aprendizado'}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{mission.description}</p>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Progresso</span>
                          <span>{mission.progress}%</span>
                        </div>
                        <Progress value={mission.progress} className="h-2" />
                      </div>
                    </div>
                    <div className="flex flex-col items-center mt-3 sm:mt-0 sm:ml-4 sm:w-32">
                      <div className="flex items-center mb-2">
                        <Award className="h-4 w-4 text-amber-500 mr-1" />
                        <span className="font-semibold">{mission.reward} pts</span>
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => handleMissionComplete(mission.id)}
                        disabled={mission.progress < 100}
                      >
                        {mission.progress >= 100 ? 'Reivindicar' : 'Continuar'}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Próximas Consultas */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Próximas Consultas
              </CardTitle>
              <CardDescription>
                Suas sessões agendadas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {appointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-moss-100 flex items-center justify-center">
                        <Calendar className="h-5 w-5 text-moss-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold">
                          {format(new Date(apt.date), "EEEE, d 'de' MMMM", { locale: ptBR })}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(apt.date), 'HH:mm')} • {apt.professional}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={
                        apt.type === 'online' 
                          ? 'border-blue-200 text-blue-700' 
                          : 'border-green-200 text-green-700'
                      }>
                        {apt.type === 'online' ? 'Online' : 'Presencial'}
                      </Badge>
                      {apt.status === 'confirmed' ? (
                        <Badge className="bg-green-100 text-green-800">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Confirmada
                        </Badge>
                      ) : (
                        <Badge variant="outline">Agendada</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-4" variant="outline">
                Ver Todas as Consultas
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Coluna Direita */}
        <div className="space-y-6">
          {/* Progresso Geral */}
          <Card>
            <CardHeader>
              <CardTitle>Meu Progresso</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-moss-600" />
                    <span className="text-sm">Engajamento</span>
                  </div>
                  <span className="font-semibold">85%</span>
                </div>
                <Progress value={85} className="h-2" />
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Missões Concluídas</span>
                  </div>
                  <span className="font-semibold">12</span>
                </div>
                <Progress value={60} className="h-2" />
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4 text-blue-600" />
                    <span className="text-sm">Conteúdo Consumido</span>
                  </div>
                  <span className="font-semibold">75%</span>
                </div>
                <Progress value={75} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Trilhas de Aprendizado */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Trilhas de Aprendizado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {learningPaths.map((path) => (
                  <Link
                    key={path.id}
                    href={`/paciente/trilhas/${path.id}`}
                    className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold">{path.title}</h4>
                      <Badge className={path.color}>
                        {path.completed}/{path.modules}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {path.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <Progress 
                        value={(path.completed / path.modules) * 100} 
                        className="h-1.5 flex-1 mr-2"
                      />
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </Link>
                ))}
              </div>
              <Button className="w-full mt-4" variant="outline" asChild>
                <Link href="/paciente/trilhas">
                  Ver Todas as Trilhas
                </Link>
              </Button>
            </CardContent>
          </Card>

          {/* Recompensas */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Minhas Conquistas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-2">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div
                    key={i}
                    className="aspect-square rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center"
                  >
                    <Award className="h-6 w-6 text-amber-500" />
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <p className="text-sm text-muted-foreground">
                  Complete missões para desbloquear conquistas
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Dica do Dia */}
      <Card className="bg-gradient-to-r from-moss-50 to-beige-50 border-moss-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-moss-100 flex items-center justify-center flex-shrink-0">
              <Target className="h-6 w-6 text-moss-600" />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Dica do Dia</h3>
              <p className="text-moss-700">
                Pratique 5 minutos de respiração consciente hoje. Sente-se confortavelmente, 
                feche os olhos e foque apenas na sua respiração. Quando sua mente divagar, 
                gentilmente traga sua atenção de volta à respiração.
              </p>
              <div className="flex items-center gap-2 mt-3">
                <Clock className="h-4 w-4 text-moss-600" />
                <span className="text-sm text-moss-600">5 minutos • Para ansiedade</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}