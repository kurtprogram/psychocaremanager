import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { googleCalendarService } from '@/services/integration/google-calendar.service'
import { authConfig } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const authUrl = await googleCalendarService.getAuthUrl(session.user.id)
    
    return NextResponse.json({ authUrl })
  } catch (error) {
    console.error('Error generating auth URL:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar Google Calendar' },
      { status: 500 }
    )
  }
}