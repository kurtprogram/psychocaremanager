import { prisma } from '@/lib/prisma'
import { stripeService } from './integration/stripe.service'
import { addDays, isBefore, differenceInDays } from 'date-fns'

class SubscriptionService {
  async checkTrialStatus(organizationId: string) {
    const organization = await prisma.organization.findUnique({
      where: { id: organizationId },
      include: { users: true },
    })

    if (!organization) return { valid: false }

    // Se já tem assinatura ativa
    if (organization.status === 'ACTIVE' && organization.stripeSubscriptionId) {
      return { 
        valid: true, 
        type: 'active',
        plan: organization.type,
        endsAt: organization.subscriptionEnd,
        daysLeft: organization.subscriptionEnd 
          ? differenceInDays(new Date(organization.subscriptionEnd), new Date())
          : null
      }
    }

    // Se está no trial
    if (organization.status === 'TRIAL' && organization.trialEndsAt) {
      const trialEnd = new Date(organization.trialEndsAt)
      const now = new Date()
      
      if (isBefore(now, trialEnd)) {
        const daysLeft = differenceInDays(trialEnd, now)
        
        return {
          valid: true,
          type: 'trial',
          plan: organization.type,
          endsAt: trialEnd,
          daysLeft,
          warning: daysLeft <= 3 ? `Seu trial termina em ${daysLeft} dias` : null,
          features: this.getPlanFeatures(organization.type)
        }
      } else {
        // Trial expirado
        await this.suspendOrganization(organizationId)
        return {
          valid: false,
          type: 'expired',
          message: 'Trial expirado. Atualize seu plano.',
          canUpgrade: true
        }
      }
    }

    // Suspenso ou cancelado
    return {
      valid: false,
      type: organization.status.toLowerCase(),
      message: 'Sua conta está suspensa. Entre em contato com o suporte.',
      canUpgrade: organization.status === 'SUSPENDED'
    }
  }

  private getPlanFeatures(planType: string) {
    const features = {
      INDIVIDUAL: [
        'Até 100 pacientes',
        'Agendamento ilimitado',
        'Google Calendar sync',
        'WhatsApp automático',
        'Prontuários eletrônicos',
        'Relatórios básicos'
      ],
      CLINIC: [
        'Até 10 profissionais',
        'Agendas compartilhadas',
        'Gestão hierárquica',
        'WhatsApp ilimitado',
        'Relatórios avançados',
        'Suporte prioritário'
      ],
      ENTERPRISE: [
        'Profissionais ilimitados',
        'API personalizada',
        'White-label',
        'Suporte 24/7',
        'Treinamento dedicado',
        'Customização total'
      ]
    }

    return features[planType as keyof typeof features] || []
  }

  async suspendOrganization(organizationId: string) {
    await prisma.organization.update({
      where: { id: organizationId },
      data: {
        status: 'SUSPENDED',
        features: {
          appointments: false,
          newPatients: false,
          whatsapp: false,
          reports: false,
          patientArea: false,
        },
      },
    })

    // Notificar usuários
    const users = await prisma.user.findMany({
      where: { organizationId },
    })

    for (const user of users) {
      await prisma.notification.create({
        data: {
          organizationId,
          userId: user.id,
          type: 'SUBSCRIPTION_EXPIRED',
          channel: 'EMAIL',
          title: 'Trial Expirado',
          message: 'Seu período de trial expirou. Atualize seu plano para continuar usando o sistema.',
          status: 'PENDING',
        },
      })
    }

    // Criar log
    await prisma.auditLog.create({
      data: {
        organizationId,
        action: 'SUSPEND',
        entityType: 'ORGANIZATION',
        entityId: organizationId,
        ipAddress: 'system',
        userAgent: 'system',
      },
    })
  }

  async createSubscriptionPlan(data: {
    name: string
    type: 'INDIVIDUAL' | 'CLINIC' | 'ENTERPRISE'
    priceMonthly: number
    priceYearly: number
    features: string[]
    maxProfessionals?: number
    maxPatients?: number
    stripePriceIdMonthly?: string
    stripePriceIdYearly?: string
  }) {
    const plan = await prisma.subscriptionPlan.create({
      data: {
        name: data.name,
        type: data.type,
        priceMonthly: data.priceMonthly,
        priceYearly: data.priceYearly,
        features: data.features,
        maxProfessionals: data.maxProfessionals,
        maxPatients: data.maxPatients,
        stripePriceIdMonthly: data.stripePriceIdMonthly,
        stripePriceIdYearly: data.stripePriceIdYearly,
        isActive: true,
      },
    })

    return plan
  }

  async upgradePlan(organizationId: string, newPlanType: 'INDIVIDUAL' | 'CLINIC' | 'ENTERPRISE') {
    const organization = await prisma.organization.findUnique({
      where: { id: organizationId },
    })

    if (!organization) {
      throw new Error('Organização não encontrada')
    }

    // Calcular upgrade
    const updates: any = {
      type: newPlanType,
      status: 'ACTIVE',
      features: this.getPlanFeatures(newPlanType),
      maxProfessionals: newPlanType === 'CLINIC' ? 10 : newPlanType === 'ENTERPRISE' ? null : 1,
      maxPatients: newPlanType === 'ENTERPRISE' ? null : 1000,
      subscriptionStart: new Date(),
      subscriptionEnd: addDays(new Date(), 30), // 30 dias
    }

    // Se estava suspenso, reativar features
    if (organization.status === 'SUSPENDED') {
      updates.features = {
        appointments: true,
        newPatients: true,
        whatsapp: true,
        reports: true,
        patientArea: true,
      }
    }

    const updatedOrg = await prisma.organization.update({
      where: { id: organizationId },
      data: updates,
    })

    // Registrar mudança
    await prisma.auditLog.create({
      data: {
        organizationId,
        action: 'UPGRADE_PLAN',
        entityType: 'ORGANIZATION',
        entityId: organizationId,
        before: { 
          plan: organization.type,
          status: organization.status 
        },
        after: { 
          plan: updatedOrg.type,
          status: updatedOrg.status 
        },
      },
    })

    // Notificar usuários
    const users = await prisma.user.findMany({
      where: { organizationId },
    })

    for (const user of users) {
      await prisma.notification.create({
        data: {
          organizationId,
          userId: user.id,
          type: 'PLAN_UPGRADED',
          channel: 'EMAIL',
          title: 'Plano Atualizado!',
          message: `Seu plano foi atualizado para ${newPlanType}. Todos os recursos estão disponíveis.`,
          status: 'PENDING',
        },
      })
    }

    return updatedOrg
  }

  async checkOrganizationLimits(organizationId: string) {
    const organization = await prisma.organization.findUnique({
      where: { id: organizationId },
      include: {
        _count: {
          select: {
            users: true,
            patients: true,
          },
        },
      },
    })

    if (!organization) return { valid: false }

    const limits = {
      maxProfessionals: organization.maxProfessionals,
      maxPatients: organization.maxPatients,
      currentProfessionals: organization._count.users,
      currentPatients: organization._count.patients,
      exceeded: false,
      messages: [] as string[],
    }

    // Verificar limite de profissionais
    if (limits.maxProfessionals && limits.currentProfessionals >= limits.maxProfessionals) {
      limits.exceeded = true
      limits.messages.push(`Limite de profissionais atingido (${limits.currentProfessionals}/${limits.maxProfessionals})`)
    }

    // Verificar limite de pacientes
    if (limits.maxPatients && limits.currentPatients >= limits.maxPatients) {
      limits.exceeded = true
      limits.messages.push(`Limite de pacientes atingido (${limits.currentPatients}/${limits.maxPatients})`)
    }

    return limits
  }

  async getBillingHistory(organizationId: string) {
    const payments = await prisma.payment.findMany({
      where: {
        organizationId,
        status: 'PAID',
      },
      orderBy: {
        paidAt: 'desc',
      },
      take: 12, // últimos 12 meses
    })

    return payments
  }
}

export const subscriptionService = new SubscriptionService()