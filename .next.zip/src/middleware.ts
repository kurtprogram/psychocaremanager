export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api/auth (auth API routes)
     * - api/patients (patients API - precisa de auth)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public (public files)
     * - login, cadastro, termos, privacidade, lgpd (public pages)
     */
    '/((?!api/auth|_next/static|_next/image|favicon.ico|public|login|cadastro|termos|privacidade|lgpd|planos|recuperar-senha).*)',
  ],
}