import { z } from 'zod'

// Validação de email com regex avançado
export const emailSchema = z.string()
  .min(1, 'Email é obrigatório')
  .email('Email inválido')
  .refine((email) => {
    // Verifica se é um provedor válido
    const validProviders = [
      'gmail.com', 'gmail.com.br',
      'hotmail.com', 'outlook.com', 'live.com',
      'yahoo.com', 'yahoo.com.br',
      'icloud.com',
      'protonmail.com',
      // Domínios corporativos brasileiros comuns
      '.com.br', '.br', '.gov.br', '.org.br'
    ]
    
    const domain = email.split('@')[1]?.toLowerCase()
    if (!domain) return false
    
    // Aceita qualquer email, mas verifica se é válido
    return /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(domain)
  }, {
    message: 'Domínio de email inválido'
  })
  .refine((email) => {
    // Verifica se não é email temporário
    const tempDomains = [
      'tempmail.com', '10minutemail.com', 'guerrillamail.com',
      'mailinator.com', 'throwawaymail.com', 'yopmail.com'
    ]
    
    const domain = email.split('@')[1]?.toLowerCase()
    return !tempDomains.some(temp => domain?.includes(temp))
  }, {
    message: 'Emails temporários não são permitidos'
  })

// Validação específica para Gmail
export const gmailSchema = emailSchema.refine((email) => {
  const domain = email.split('@')[1]?.toLowerCase()
  return domain === 'gmail.com' || domain === 'googlemail.com'
}, {
  message: 'Apenas emails do Google são permitidos'
})

// Validação completa de usuário
export const userSchema = z.object({
  name: z.string()
    .min(2, 'Nome muito curto (mínimo 2 caracteres)')
    .max(100, 'Nome muito longo (máximo 100 caracteres)')
    .regex(/^[a-zA-ZÀ-ÿ\s']+$/, 'Apenas letras e espaços são permitidos'),
  
  email: emailSchema,
  
  password: z.string()
    .min(8, 'Senha deve ter no mínimo 8 caracteres')
    .regex(/[A-Z]/, 'Deve conter pelo menos uma letra maiúscula')
    .regex(/[a-z]/, 'Deve conter pelo menos uma letra minúscula')
    .regex(/[0-9]/, 'Deve conter pelo menos um número')
    .regex(/[^A-Za-z0-9]/, 'Deve conter pelo menos um caractere especial'),
  
  phone: z.string()
    .regex(/^\(\d{2}\) \d{4,5}-\d{4}$/, 'Formato inválido. Use: (11) 99999-9999')
    .transform((phone) => phone.replace(/\D/g, '')), // Remove não-dígitos
  
  cpf: z.string()
    .optional()
    .refine((cpf) => !cpf || validateCPF(cpf), 'CPF inválido'),
})

// Função para validar CPF
export function validateCPF(cpf: string): boolean {
  cpf = cpf.replace(/\D/g, '')
  
  if (cpf.length !== 11) return false
  if (/^(\d)\1{10}$/.test(cpf)) return false // Todos dígitos iguais
  
  let sum = 0
  let remainder
  
  for (let i = 1; i <= 9; i++) {
    sum += parseInt(cpf.substring(i - 1, i)) * (11 - i)
  }
  
  remainder = (sum * 10) % 11
  if (remainder === 10 || remainder === 11) remainder = 0
  if (remainder !== parseInt(cpf.substring(9, 10))) return false
  
  sum = 0
  for (let i = 1; i <= 10; i++) {
    sum += parseInt(cpf.substring(i - 1, i)) * (12 - i)
  }
  
  remainder = (sum * 10) % 11
  if (remainder === 10 || remainder === 11) remainder = 0
  if (remainder !== parseInt(cpf.substring(10, 11))) return false
  
  return true
}

// Validação de email do paciente
export const patientEmailSchema = emailSchema
  .optional()
  .or(z.literal(''))
  .refine((email) => {
    if (!email) return true // Email é opcional
    return emailSchema.safeParse(email).success
  }, {
    message: 'Email inválido'
  })

// Verificar se email é corporativo
export function isCorporateEmail(email: string): boolean {
  const domain = email.split('@')[1]?.toLowerCase() || ''
  const corporateKeywords = [
    'hospital', 'clinica', 'psicologia', 'saude', 'med',
    'consultorio', 'terapia', 'instituto', 'centro'
  ]
  
  return corporateKeywords.some(keyword => domain.includes(keyword))
}

// Verificar força do email (para priorização)
export function getEmailStrength(email: string): 'high' | 'medium' | 'low' {
  const domain = email.split('@')[1]?.toLowerCase() || ''
  
  // Emails corporativos são alta prioridade
  if (isCorporateEmail(email)) return 'high'
  
  // Gmail/Outlook são média prioridade
  if (domain.includes('gmail') || domain.includes('outlook') || domain.includes('hotmail')) {
    return 'medium'
  }
  
  // Outros são baixa prioridade (maior chance de ser fake)
  return 'low'
}