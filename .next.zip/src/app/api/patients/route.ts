import { NextRequest, NextResponse } from 'next/server'
import getServerSession from 'next-auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import { authConfig } from '@/lib/auth'

const patientSchema = z.object({
  fullName: z.string().min(3, 'Nome muito curto'),
  email: z.string().email('Email inválido').optional().or(z.literal('')),
  phone: z.string().min(10, 'Telefone inválido'),
  whatsapp: z.string().optional(),
  dateOfBirth: z.string().optional(),
  gender: z.string().optional(),
  cpf: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  insuranceProvider: z.string().optional(),
  insuranceNumber: z.string().optional(),
  allergies: z.string().optional(),
  medications: z.string().optional(),
  medicalConditions: z.string().optional(),
})

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const patients = await prisma.patient.findMany({
      where: {
        organizationId: session.user.organizationId,
        deletedAt: null,
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: 100,
    })

    return NextResponse.json(patients)
  } catch (error) {
    console.error('Error fetching patients:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar pacientes' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authConfig) as any
    
    if (!session?.user?.organizationId) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      )
    }

    const body = await req.json()
    
    // Validar dados
    const validated = patientSchema.parse(body)

    // Verificar se telefone já existe
    const existingPatient = await prisma.patient.findUnique({
      where: {
        phone: validated.phone,
        organizationId: session.user.organizationId,
      },
    })

    if (existingPatient) {
      return NextResponse.json(
        { error: 'Já existe um paciente com este telefone' },
        { status: 400 }
      )
    }

    // Criar paciente
    const patient = await prisma.patient.create({
      data: {
        organizationId: session.user.organizationId,
        fullName: validated.fullName,
        email: validated.email || null,
        phone: validated.phone,
        whatsapp: validated.whatsapp || validated.phone,
        dateOfBirth: validated.dateOfBirth ? new Date(validated.dateOfBirth) : null,
        gender: validated.gender || null,
        cpf: validated.cpf || null,
        address: validated.address || null,
        city: validated.city || null,
        state: validated.state || null,
        emergencyContactName: validated.emergencyContactName || null,
        emergencyContactPhone: validated.emergencyContactPhone || null,
        insuranceProvider: validated.insuranceProvider || null,
        insuranceNumber: validated.insuranceNumber || null,
        allergies: validated.allergies || null,
        medications: validated.medications || null,
        medicalConditions: validated.medicalConditions || null,
        status: 'ACTIVE',
      },
    })

    // Criar log de auditoria
    await prisma.auditLog.create({
      data: {
        organizationId: session.user.organizationId,
        userId: session.user.id,
        userEmail: session.user.email!,
        userName: session.user.name!,
        action: 'CREATE',
        entityType: 'PATIENT',
        entityId: patient.id,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown',
        userAgent: req.headers.get('user-agent') || 'unknown',
      },
    })

    return NextResponse.json({
      success: true,
      patient,
    })

  } catch (error: any) {
    console.error('Error creating patient:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Erro ao criar paciente' },
      { status: 500 }
    )
  }
}