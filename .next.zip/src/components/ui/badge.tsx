import * as React from 'react'

export function Badge({ children, variant, className = '', ...props }: { variant?: string } & React.HTMLAttributes<HTMLSpanElement>) {
  return (
    <span className={`inline-flex items-center gap-2 px-2 py-1 rounded-full text-sm ${className}`} data-variant={variant} {...props}>
      {children}
    </span>
  )
}
