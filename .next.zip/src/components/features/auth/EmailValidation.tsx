'use client'

import { useState, useEffect } from 'react'
import { CheckCircle, XCircle, AlertCircle, Mail, Loader2 } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { emailSchema, getEmailStrength, isCorporateEmail } from '@/lib/validation'
import { cn } from '@/lib/utils'

interface EmailValidationProps {
  value: string
  onChange: (email: string) => void
  onValidationChange?: (isValid: boolean) => void
  disabled?: boolean
  required?: boolean
  className?: string
}

export default function EmailValidation({
  value,
  onChange,
  onValidationChange,
  disabled = false,
  required = true,
  className
}: EmailValidationProps) {
  const [isValid, setIsValid] = useState<boolean | null>(null)
  const [isChecking, setIsChecking] = useState(false)
  const [validationMessage, setValidationMessage] = useState('')
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [hasFocus, setHasFocus] = useState(false)

  // Verificar email em tempo real
  useEffect(() => {
    const validateEmail = async () => {
      if (!value.trim()) {
        setIsValid(null)
        setValidationMessage('')
        setSuggestions([])
        onValidationChange?.(false)
        return
      }

      setIsChecking(true)

      try {
        // Validação básica com Zod
        const result = emailSchema.safeParse(value)
        
        if (!result.success) {
          setIsValid(false)
          setValidationMessage(result.error.errors[0].message)
          setSuggestions([])
          onValidationChange?.(false)
          return
        }

        // Verificação adicional de domínio
        const domain = value.split('@')[1]?.toLowerCase()
        const commonTypos: Record<string, string> = {
          'gmial.com': 'gmail.com',
          'gmal.com': 'gmail.com',
          'gmail.con': 'gmail.com',
          'hotmail.con': 'hotmail.com',
          'outlook.con': 'outlook.com',
          'yahoo.con': 'yahoo.com',
          'gmail.com.br': 'gmail.com',
        }

        // Sugerir correção para erros comuns
        if (domain && commonTypos[domain]) {
          const correctedEmail = value.split('@')[0] + '@' + commonTypos[domain]
          setSuggestions([correctedEmail])
          setIsValid(false)
          setValidationMessage('Domínio incorreto detectado')
          onValidationChange?.(false)
          return
        }

        // Verificar MX records (em produção)
        // const mxValid = await checkMXRecords(domain)
        // if (!mxValid) {
        //   setIsValid(false)
        //   setValidationMessage('Domínio não possui servidor de email válido')
        //   onValidationChange?.(false)
        //   return
        // }

        // Todas as validações passaram
        setIsValid(true)
        setValidationMessage('Email válido')
        setSuggestions([])
        onValidationChange?.(true)

      } catch (error) {
        console.error('Email validation error:', error)
        setIsValid(false)
        setValidationMessage('Erro ao validar email')
        onValidationChange?.(false)
      } finally {
        setIsChecking(false)
      }
    }

    // Debounce para não validar a cada tecla
    const timeoutId = setTimeout(() => {
      validateEmail()
    }, 500)

    return () => clearTimeout(timeoutId)
  }, [value, onValidationChange])

  // Verificar força do email
  const emailStrength = value ? getEmailStrength(value) : null
  const isCorporate = value ? isCorporateEmail(value) : false

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'high': return 'bg-green-100 text-green-800'
      case 'medium': return 'bg-amber-100 text-amber-800'
      case 'low': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStrengthLabel = (strength: string) => {
    switch (strength) {
      case 'high': return 'Alta Confiabilidade'
      case 'medium': return 'Média Confiabilidade'
      case 'low': return 'Baixa Confiabilidade'
      default: return 'Não avaliado'
    }
  }

  const handleSuggestionClick = (suggestedEmail: string) => {
    onChange(suggestedEmail)
  }

  return (
    <div className={cn('space-y-3', className)}>
      <div className="space-y-2">
        <Label htmlFor="email" className="flex items-center gap-2">
          <Mail className="h-4 w-4" />
          Email {required && '*'}
        </Label>
        
        <div className="relative">
          <Input
            id="email"
            type="email"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onFocus={() => setHasFocus(true)}
            onBlur={() => setHasFocus(false)}
            disabled={disabled || isChecking}
            placeholder="seu@email.com"
            className={cn(
              'pl-10',
              isValid === true && 'border-green-500',
              isValid === false && 'border-red-500',
              hasFocus && 'ring-2 ring-moss-500 ring-opacity-50'
            )}
            aria-invalid={isValid === false}
            aria-describedby="email-validation"
          />
          
          <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          
          {isChecking && (
            <Loader2 className="absolute right-3 top-3 h-4 w-4 animate-spin text-muted-foreground" />
          )}
          
          {!isChecking && isValid === true && (
            <CheckCircle className="absolute right-3 top-3 h-4 w-4 text-green-500" />
          )}
          
          {!isChecking && isValid === false && (
            <XCircle className="absolute right-3 top-3 h-4 w-4 text-red-500" />
          )}
        </div>

        {/* Feedback de validação */}
        {validationMessage && (
          <div
            id="email-validation"
            className={cn(
              'flex items-center gap-2 text-sm p-2 rounded-md',
              isValid === true && 'bg-green-50 text-green-700',
              isValid === false && 'bg-red-50 text-red-700',
              isValid === null && 'bg-blue-50 text-blue-700'
            )}
            role="alert"
          >
            {isValid === false ? (
              <XCircle className="h-4 w-4 flex-shrink-0" />
            ) : isValid === true ? (
              <CheckCircle className="h-4 w-4 flex-shrink-0" />
            ) : (
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
            )}
            <span>{validationMessage}</span>
          </div>
        )}

        {/* Sugestões */}
        {suggestions.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Você quis dizer?</p>
            <div className="flex flex-wrap gap-2">
              {suggestions.map((suggestion, index) => (
                <Button
                  key={index}
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="text-xs"
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Informações adicionais */}
        {value && (
          <div className="space-y-2 pt-2 border-t">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Confiança:</span>
              {emailStrength && (
                <Badge className={getStrengthColor(emailStrength)}>
                  {getStrengthLabel(emailStrength)}
                </Badge>
              )}
            </div>
            
            {isCorporate && (
              <div className="flex items-center gap-2 text-sm text-green-600">
                <CheckCircle className="h-4 w-4" />
                <span>Email corporativo detectado</span>
              </div>
            )}
            
            {/* Dicas para emails inválidos */}
            {isValid === false && (
              <div className="space-y-1 text-sm text-muted-foreground">
                <p className="font-medium">Dicas:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Verifique se digitou corretamente (ex: @gmail.com)</li>
                  <li>Evite espaços ou caracteres especiais</li>
                  <li>Use um email pessoal ou corporativo válido</li>
                  <li>Emails temporários não são aceitos</li>
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// Função para verificar MX records (em produção)
async function checkMXRecords(domain: string): Promise<boolean> {
  if (process.env.NODE_ENV === 'development') {
    // Em desenvolvimento, simula verificação
    return new Promise(resolve => {
      setTimeout(() => {
        // Domínios conhecidos como válidos
        const validDomains = ['gmail.com', 'outlook.com', 'hotmail.com', 'yahoo.com', 'icloud.com']
        const hasValidDomain = validDomains.some(valid => domain.includes(valid))
        resolve(hasValidDomain)
      }, 100)
    })
  }
  
  // Em produção, faria uma verificação real
  return true
}