'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { useToast } from '@/hooks/useToast'
import { Loader2, User, Phone, Building, Shield, AlertCircle } from 'lucide-react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import EmailValidation from '@/components/features/auth/EmailValidation'
import { userSchema } from '@/lib/validation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

// Schema extendido para cadastro
const registerSchema = userSchema.extend({
  confirmPassword: z.string(),
  planType: z.enum(['INDIVIDUAL', 'CLINIC', 'ENTERPRISE']),
  acceptTerms: z.boolean().refine(val => val === true, {
    message: 'Você deve aceitar os termos'
  }),
  clinicName: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'As senhas não coincidem',
  path: ['confirmPassword']
})

type RegisterFormData = z.infer<typeof registerSchema>

export default function RegisterPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [emailValid, setEmailValid] = useState(false)

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isValid }
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    mode: 'onChange'
  })

  const planType = watch('planType')
  const isClinic = planType === 'CLINIC' || planType === 'ENTERPRISE'

  const onSubmit = async (data: RegisterFormData) => {
    if (!emailValid) {
      toast({
        title: 'Email inválido',
        description: 'Por favor, corrija seu email antes de continuar',
        variant: 'destructive',
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: data.name,
          email: data.email,
          password: data.password,
          phone: data.phone,
          planType: data.planType,
          clinicName: isClinic ? data.clinicName : undefined,
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Erro ao criar conta')
      }

      toast({
        title: 'Conta criada com sucesso!',
        description: 'Redirecionando para o dashboard...',
      })

      // Auto login
      setTimeout(() => {
        router.push('/dashboard?welcome=true')
      }, 1500)

    } catch (error: any) {
      toast({
        title: 'Erro ao criar conta',
        description: error.message,
        variant: 'destructive',
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="w-full">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Crie sua conta profissional</h1>
        <p className="text-muted-foreground">
          Comece sua jornada com 7 dias grátis
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Tipo de Plano */}
        <div className="space-y-2">
          <Label htmlFor="planType">Tipo de Plano *</Label>
          <Select
            onValueChange={(value: 'INDIVIDUAL' | 'CLINIC' | 'ENTERPRISE') => 
              setValue('planType', value)
            }
            defaultValue="INDIVIDUAL"
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione seu plano" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="INDIVIDUAL">
                <div className="flex items-center">
                  <User className="mr-2 h-4 w-4" />
                  <span>Individual (Psicólogo Autônomo)</span>
                </div>
              </SelectItem>
              <SelectItem value="CLINIC">
                <div className="flex items-center">
                  <Building className="mr-2 h-4 w-4" />
                  <span>Clínica (Até 10 profissionais)</span>
                </div>
              </SelectItem>
              <SelectItem value="ENTERPRISE">
                <div className="flex items-center">
                  <Building className="mr-2 h-4 w-4" />
                  <span>Empresarial (Ilimitado)</span>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
          {errors.planType && (
            <p className="text-sm text-red-600">{errors.planType.message}</p>
          )}
        </div>

        {/* Nome da Clínica (se aplicável) */}
        {isClinic && (
          <div className="space-y-2">
            <Label htmlFor="clinicName">Nome da Clínica/Empresa *</Label>
            <Input
              id="clinicName"
              {...register('clinicName')}
              disabled={isLoading}
              placeholder="Ex: Centro de Psicologia Integrada"
            />
            {errors.clinicName && (
              <p className="text-sm text-red-600">{errors.clinicName.message}</p>
            )}
          </div>
        )}

        {/* Informações Pessoais */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Informações Pessoais</CardTitle>
            <CardDescription>
              Seus dados de contato principais
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo *</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="name"
                  {...register('name')}
                  disabled={isLoading}
                  placeholder={isClinic ? "Nome do responsável" : "Seu nome completo"}
                  className="pl-10"
                />
              </div>
              {errors.name && (
                <p className="text-sm text-red-600">{errors.name.message}</p>
              )}
            </div>

            <EmailValidation
              value={watch('email') || ''}
              onChange={(email) => setValue('email', email, { shouldValidate: true })}
              onValidationChange={setEmailValid}
              disabled={isLoading}
              required
            />
            {errors.email && !emailValid && (
              <p className="text-sm text-red-600">{errors.email.message}</p>
            )}

            <div className="space-y-2">
              <Label htmlFor="phone">Telefone/WhatsApp *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="phone"
                  {...register('phone')}
                  disabled={isLoading}
                  placeholder="(11) 99999-9999"
                  className="pl-10"
                />
              </div>
              {errors.phone && (
                <p className="text-sm text-red-600">{errors.phone.message}</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Segurança */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Segurança</CardTitle>
            <CardDescription>
              Crie uma senha forte para proteger sua conta
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="password">Senha *</Label>
              <div className="relative">
                <Shield className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  {...register('password')}
                  disabled={isLoading}
                  placeholder="••••••••"
                  className="pl-10"
                />
              </div>
              {errors.password && (
                <p className="text-sm text-red-600">{errors.password.message}</p>
              )}
              <div className="text-sm text-muted-foreground space-y-1">
                <p>A senha deve conter:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li className={watch('password')?.match(/[A-Z]/) ? 'text-green-600' : ''}>
                    Pelo menos uma letra maiúscula
                  </li>
                  <li className={watch('password')?.match(/[a-z]/) ? 'text-green-600' : ''}>
                    Pelo menos uma letra minúscula
                  </li>
                  <li className={watch('password')?.match(/[0-9]/) ? 'text-green-600' : ''}>
                    Pelo menos um número
                  </li>
                  <li className={watch('password')?.match(/[^A-Za-z0-9]/) ? 'text-green-600' : ''}>
                    Pelo menos um caractere especial
                  </li>
                  <li className={(watch('password')?.length || 0) >= 8 ? 'text-green-600' : ''}>
                    Mínimo de 8 caracteres
                  </li>
                </ul>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar Senha *</Label>
              <div className="relative">
                <Shield className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="confirmPassword"
                  type="password"
                  {...register('confirmPassword')}
                  disabled={isLoading}
                  placeholder="••••••••"
                  className="pl-10"
                />
              </div>
              {errors.confirmPassword && (
                <p className="text-sm text-red-600">{errors.confirmPassword.message}</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Termos e Condições */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start space-x-3">
              <Checkbox
                id="acceptTerms"
                checked={watch('acceptTerms')}
                onCheckedChange={(checked) => 
                  setValue('acceptTerms', checked === true, { shouldValidate: true })
                }
                disabled={isLoading}
              />
              <div className="space-y-1">
                <Label htmlFor="acceptTerms" className="text-sm font-normal leading-none">
                  Concordo com os{' '}
                  <Link href="/termos" className="text-moss-600 hover:underline">
                    Termos de Uso
                  </Link>{' '}
                  e{' '}
                  <Link href="/privacidade" className="text-moss-600 hover:underline">
                    Política de Privacidade
                  </Link>
                </Label>
                {errors.acceptTerms && (
                  <p className="text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="h-4 w-4" />
                    {errors.acceptTerms.message}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Botão de Submissão */}
        <Button 
          type="submit" 
          className="w-full" 
          disabled={isLoading || !isValid || !emailValid}
        >
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Criar Conta Grátis
        </Button>
      </form>

      {/* Informações do Trial */}
      <Card className="mt-6">
        <CardContent className="pt-6">
          <div className="space-y-3">
            <h3 className="font-semibold text-lg">🎁 Teste Grátis de 7 Dias</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span>Acesso a todas as funcionalidades do plano escolhido</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span>Sem necessidade de cartão de crédito</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span>Seus dados salvos mesmo após o término do teste</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span>Upgrade ou cancelamento a qualquer momento</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Link para Login */}
      <div className="mt-6 text-center">
        <p className="text-sm text-muted-foreground">
          Já possui uma conta?{' '}
          <Link href="/login" className="text-moss-600 font-semibold hover:underline">
            Faça login
          </Link>
        </p>
      </div>
    </div>
  )
}